import { lazy, Suspense, useEffect, useMemo, useRef, useState } from 'react'
import { hasWebGL, useInView } from '../hooks/useEnv'
import WatchFallback from './WatchFallback'

// three.js + R3F are split into their own chunk and only fetched when a stage is first needed.
const Watch3D = lazy(() => import('./Watch3D'))

/**
 * Mounts a WebGL watch only while it is near the viewport (and pauses rendering
 * when it is fully off-screen) so unused GL contexts and GPU memory are released.
 */
export default function WatchStage({
  ctrl,
  className = '',
  lighting = 'studio',
  reflect = false,
  drag = false,
  eager = false,
  label = 'AURELIS ONE smartwatch, rendered in 3D',
}) {
  const ref = useRef(null)
  const near = useInView(ref, '500px')
  const visible = useInView(ref, '0px')
  const webgl = useMemo(() => hasWebGL(), [])
  const [ready, setReady] = useState(false)
  const mount = eager || near

  useEffect(() => {
    if (!mount) setReady(false)
  }, [mount])

  return (
    <div ref={ref} className={`${/\b(absolute|fixed)\b/.test(className) ? '' : 'relative'} ${className}`} role="img" aria-label={label}>
      {webgl ? (
        mount && (
          <Suspense fallback={null}>
            <div className="absolute inset-0 transition-opacity duration-1000" style={{ opacity: ready ? 1 : 0 }}>
              <Watch3D
                ctrl={ctrl}
                lighting={lighting}
                reflect={reflect}
                drag={drag}
                active={visible}
                onReady={() => setReady(true)}
                className="!absolute inset-0"
              />
            </div>
          </Suspense>
        )
      ) : (
        <WatchFallback ctrl={ctrl} />
      )}
    </div>
  )
}
