import { useLayoutEffect, useRef } from 'react'
import WatchStage from './WatchStage'
import { gsap } from '../lib/gsap'
import { makeCtrl } from '../lib/watchConfig'
import { prefersReducedMotion } from '../hooks/useEnv'

const CALLOUTS = [
  { t: 'Glanceable display', d: 'Time and rings, readable in a flick of the wrist.', pos: 'lg:left-[7vw] lg:top-[46%]', line: 'right' },
  { t: 'Quiet notifications', d: 'Only what matters, then gone.', pos: 'lg:right-[7vw] lg:top-[42%]', line: 'left' },
  { t: 'Health at a glance', d: 'Concept: rhythm, sleep and activity summaries.', pos: 'lg:left-[7vw] lg:top-[68%]', line: 'right' },
  { t: 'Power, simply shown', d: 'Concept: battery and charging status.', pos: 'lg:right-[7vw] lg:top-[64%]', line: 'left' },
]

export default function CampaignSection() {
  const root = useRef(null)
  const ctrl = useRef(
    makeCtrl({ rotY: 0.5, rotX: 0.06, camZ: typeof window !== 'undefined' && window.innerWidth < 1024 ? 31 : 22, light: 0.85, display: 1, glow: 0.5, float: 1, pointer: 1, shiftY: 0.03, screen: { type: 'face', key: 'digital' } }),
  )

  useLayoutEffect(() => {
    if (prefersReducedMotion()) {
      Object.assign(ctrl.current, { camZ: 15, rotY: -0.3 })
      return
    }
    const c = ctrl.current
    const mm = gsap.matchMedia()
    const ctx = gsap.context(() => {
      mm.add({ desktop: '(min-width: 1024px)' }, (m) => {
        const D = m.conditions.desktop
        const items = gsap.utils.toArray('[data-callout]', root.current)
        gsap.set(items, { autoAlpha: 0, y: 24 })
        gsap.set('[data-cline]', { scaleX: 0 })
        gsap.set('[data-camp-title] [data-ci]', { yPercent: 108 })
        const tl = gsap.timeline({
          defaults: { ease: 'power2.inOut' },
          scrollTrigger: { trigger: root.current, start: 'top top', end: '+=320%', scrub: 1, pin: true, anticipatePin: 1 },
        })
        tl.to('[data-camp-title] [data-ci]', { yPercent: 0, duration: 0.5, ease: 'power4.out', stagger: 0.12 }, 0)
          .to(c, { camZ: D ? 14.5 : 21, rotY: -0.3, duration: 4, ease: 'none' }, 0)
          .to(c, { rotY: 0.35, duration: 2, ease: 'none' }, 2)
        items.forEach((el, i) => {
          const at = 0.6 + i * 0.85
          tl.to(el, { autoAlpha: 1, y: 0, duration: 0.35, ease: 'power3.out' }, at)
          tl.to(el.querySelector('[data-cline]'), { scaleX: 1, duration: 0.4 }, at)
          if (!D && i < items.length - 1) tl.to(el, { autoAlpha: 0, y: -16, duration: 0.25 }, at + 0.7)
        })
        tl.to({}, { duration: 0.4 })
      })
    }, root)
    return () => {
      mm.revert()
      ctx.revert()
    }
  }, [])

  return (
    <section id="technology" data-nav="technology" ref={root} className="relative h-[100svh] min-h-[620px] w-full overflow-hidden bg-[#050506]" aria-labelledby="campaign-title">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="haze-a absolute left-[5%] top-[20%] h-[60%] w-[45%] rounded-full bg-[radial-gradient(closest-side,rgba(201,169,106,0.12),transparent)]" />
        <div className="haze-b absolute right-[5%] top-[25%] h-[60%] w-[45%] rounded-full bg-[radial-gradient(closest-side,rgba(110,130,170,0.12),transparent)]" />
        <div className="absolute inset-x-0 top-[62%] h-px bg-gradient-to-r from-transparent via-white/15 to-transparent" />
      </div>

      <h2 id="campaign-title" data-camp-title className="display absolute inset-x-0 top-[14svh] z-[1] px-5 text-center text-[clamp(2.4rem,8.4vw,8.4rem)] font-extralight leading-[0.92] text-ivory" aria-label="Your world. At a glance.">
        <span className="mask block" aria-hidden="true">
          <span data-ci className="block">YOUR WORLD.</span>
        </span>
        <span className="mask block" aria-hidden="true">
          <span data-ci className="block text-champagne">AT A GLANCE.</span>
        </span>
      </h2>

      <WatchStage ctrl={ctrl} lighting="rim" className="absolute inset-0 z-[2] pointer-events-none" label="AURELIS ONE lit from behind" />
      <div className="vignette absolute inset-0 z-[3]" aria-hidden="true" />

      <div className="absolute inset-x-5 bottom-[calc(var(--tabbar)+2svh)] z-[4] grid grid-cols-2 gap-x-5 gap-y-4 lg:contents">
      {CALLOUTS.map((c, i) => (
        <div key={c.t} data-callout className={`border-t border-white/10 pt-3 lg:absolute lg:z-[4] lg:w-60 lg:border-0 lg:pt-0 ${c.pos} ${c.line === 'left' ? 'lg:text-left' : 'lg:text-right'}`}>
          <p className="eyebrow mb-1.5 lg:mb-2">0{i + 1}</p>
          <p className="text-[0.98rem] font-light leading-snug text-ivory lg:text-lg">{c.t}</p>
          <div data-cline className={`my-3 hidden h-px w-full bg-champagne/60 lg:block ${c.line === 'left' ? 'origin-left' : 'origin-right'}`} />
          <p className="mt-1 text-[0.76rem] leading-relaxed text-ivory/55 lg:mt-0 lg:text-[0.85rem]">{c.d}</p>
        </div>
      ))}
      </div>
    </section>
  )
}
