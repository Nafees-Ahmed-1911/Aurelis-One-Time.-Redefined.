import { useEffect, useRef } from 'react'
import WatchStage from './WatchStage'
import FacePreview from './FacePreview'
import { CASES, STRAPS, FACES, makeCtrl, setScreen } from '../lib/watchConfig'
import { gsap } from '../lib/gsap'
import { useApp } from '../context'
import { useScrollAnimations } from '../hooks/useScrollAnimations'

function Group({ legend, children }) {
  return (
    <fieldset className="border-t border-white/10 py-7">
      <legend className="float-left mb-5 w-full text-[0.66rem] font-medium uppercase tracking-[0.3em] text-ivory/45">{legend}</legend>
      <div className="clear-both flex flex-wrap gap-3">{children}</div>
    </fieldset>
  )
}

function Swatch({ name, value, checked, onChange, label, swatch }) {
  return (
    <label className="relative cursor-pointer">
      <input type="radio" name={name} value={value} checked={checked} onChange={onChange} className="peer sr-only" />
      <span className="flex items-center gap-3 rounded-full border border-white/15 py-2 pl-2 pr-5 text-[0.82rem] text-ivory/70 transition-all duration-500 hover:border-white/40 peer-checked:border-champagne peer-checked:bg-champagne/[0.08] peer-checked:text-ivory peer-focus-visible:outline peer-focus-visible:outline-1 peer-focus-visible:outline-offset-4 peer-focus-visible:outline-champagne">
        <span className="h-7 w-7 rounded-full ring-1 ring-white/25" style={{ background: swatch }} />
        {label}
      </span>
    </label>
  )
}

export default function WatchCustomizer() {
  const root = useRef(null)
  const { config, setConfig, openReserve } = useApp()
  const ctrl = useRef(
    makeCtrl({ rotY: -0.42, rotX: 0.1, camZ: typeof window !== 'undefined' && window.innerWidth < 640 ? 19 : 15.5, light: 1.1, display: 1, float: 1, pointer: 1, glow: 0.3, caseKey: config.case, strapKey: config.strap, screen: { type: 'face', key: config.face } }),
  )
  useScrollAnimations(root)

  const first = useRef(true)
  useEffect(() => {
    const c = ctrl.current
    c.caseKey = config.case
    c.strapKey = config.strap
    setScreen(ctrl, { type: 'face', key: config.face }, 0.7)
    if (first.current) {
      first.current = false
      return
    }
    gsap.fromTo(c, { sweep: -4.5, sweepI: 1.2 }, { sweep: 4.5, duration: 1, ease: 'power2.inOut' })
    gsap.to(c, { sweepI: 0, duration: 0.3, delay: 0.9 })
  }, [config])

  const set = (k) => (e) => setConfig((cfg) => ({ ...cfg, [k]: e.target.value }))
  const caseL = CASES.find((x) => x.key === config.case).label
  const strapL = STRAPS.find((x) => x.key === config.strap).label
  const faceL = FACES.find((x) => x.key === config.face).label

  return (
    <section id="customize" data-nav="customize" ref={root} className="relative bg-graphite py-20 sm:py-28 lg:py-40">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="mb-14 max-w-2xl lg:mb-20">
          <p data-reveal className="eyebrow mb-6">
            Make it yours
          </p>
          <h2 data-lines className="display text-[clamp(2.4rem,6vw,5.6rem)] font-extralight text-ivory" aria-label="Compose your AURELIS ONE.">
            <span className="mask block" aria-hidden="true">
              <span data-line className="block">Compose your</span>
            </span>
            <span className="mask block" aria-hidden="true">
              <span data-line className="serif-it block text-champagne">AURELIS ONE.</span>
            </span>
          </h2>
        </div>

        <div className="flex flex-col gap-8 lg:grid lg:grid-cols-12 lg:gap-16">
          <div className="sticky top-3 z-20 bg-graphite pb-2 lg:static lg:col-span-7 lg:bg-transparent lg:pb-0">
            <div className="overflow-hidden rounded-[1.5rem] sm:rounded-[2rem] border border-white/[0.07] bg-[radial-gradient(ellipse_at_50%_35%,#26282d,#0b0b0d_75%)]">
              <WatchStage ctrl={ctrl} drag className="h-[34svh] min-h-[250px] w-full cursor-grab active:cursor-grabbing sm:h-[60svh] sm:min-h-[400px] lg:h-[74svh]" label={`AURELIS ONE with ${caseL} case, ${strapL} strap and ${faceL} face`} />
            </div>
            <p className="mt-3 text-[0.62rem] leading-snug text-ivory/40 lg:mt-4 lg:text-[0.68rem] lg:leading-relaxed">
              Case, strap and face update colour and display only — the form of the watch is identical across configurations. Drag to turn.
            </p>
          </div>

          <div className="lg:col-span-5">
            <Group legend="Case">
              {CASES.map((o) => (
                <Swatch key={o.key} name="case" value={o.key} checked={config.case === o.key} onChange={set('case')} label={o.label} swatch={o.swatch} />
              ))}
            </Group>
            <Group legend="Strap">
              {STRAPS.map((o) => (
                <Swatch key={o.key} name="strap" value={o.key} checked={config.strap === o.key} onChange={set('strap')} label={o.label} swatch={o.swatch} />
              ))}
            </Group>
            <Group legend="Watch face">
              {FACES.map((o) => (
                <label key={o.key} className="relative w-[calc(33.333%-0.5rem)] cursor-pointer">
                  <input type="radio" name="face" value={o.key} checked={config.face === o.key} onChange={set('face')} className="peer sr-only" />
                  <span className="flex flex-col items-center gap-3 rounded-2xl border border-white/15 p-3 transition-all duration-500 hover:border-white/40 peer-checked:border-champagne peer-checked:bg-champagne/[0.08] peer-focus-visible:outline peer-focus-visible:outline-1 peer-focus-visible:outline-offset-4 peer-focus-visible:outline-champagne">
                    <FacePreview face={o.key} className="w-full rounded-[22%] bg-black" />
                    <span className="text-[0.62rem] uppercase tracking-[0.08em] text-ivory/75 sm:text-[0.72rem] sm:tracking-[0.18em]">{o.label}</span>
                  </span>
                </label>
              ))}
            </Group>

            <div className="border-t border-white/10 pt-7">
              <p className="text-[0.66rem] font-medium uppercase tracking-[0.3em] text-ivory/45">Your configuration</p>
              <p aria-live="polite" className="mt-4 text-xl font-light leading-snug text-ivory">
                AURELIS ONE
                <span className="block text-ivory/60">
                  {caseL} case · {strapL} strap · {faceL} face
                </span>
              </p>
              <button type="button" onClick={() => openReserve(1)} className="btn btn-primary mt-7 w-full py-4 sm:w-auto">
                Reserve this configuration
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
