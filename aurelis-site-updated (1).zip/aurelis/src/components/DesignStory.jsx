import { useRef } from 'react'
import WatchStill from './WatchStill'
import { CASES, STRAPS, makeCtrl } from '../lib/watchConfig'
import { useScrollAnimations } from '../hooks/useScrollAnimations'

const FIXED = new Date(2026, 9, 26, 10, 9, 36).getTime()

function Annotation({ x, y, label, side = 'right', light = true }) {
  return (
    <div
      className={`pointer-events-none absolute z-10 flex flex-col gap-1.5 text-[0.55rem] font-medium uppercase tracking-[0.16em] sm:flex-row sm:items-center sm:gap-3 sm:text-[0.6rem] sm:tracking-[0.26em] ${
        x > 45 ? '-translate-x-1/2 items-center text-center sm:translate-x-0 sm:text-left' : 'items-start'
      } ${light ? 'text-ivory/90' : 'text-obsidian/70'} ${side === 'left' ? 'sm:flex-row-reverse' : ''}`}
      style={{ left: `${x}%`, top: `${y}%` }}
    >
      <span className="relative block h-2 w-2 rounded-full bg-champagne">
        <span className="absolute inset-0 animate-ping rounded-full bg-champagne/60 motion-reduce:hidden" />
      </span>
      <span className="hidden h-px w-10 bg-champagne/80 sm:block sm:w-16" />
      <span className="max-w-[8.5rem] rounded-full bg-black/60 px-2.5 py-1 leading-snug backdrop-blur-sm sm:max-w-none sm:bg-transparent sm:p-0 sm:backdrop-blur-none">{label}</span>
    </div>
  )
}

export default function DesignStory() {
  const root = useRef(null)
  useScrollAnimations(root)

  const macro = useRef(
    makeCtrl({ rotY: -0.95, rotX: 0.2, camZ: 7.4, pivotX: 1.45, pivotY: 0.7, shiftX: 0.2, light: 1.15, display: 1, sweep: -2.5, sweepI: 0.9, pointer: 0, float: 0, fixedTime: FIXED, screen: { type: 'face', key: 'minimal' } }),
  )
  const crown = useRef(
    makeCtrl({ rotY: -0.82, rotX: 0.12, camZ: 4.6, pivotX: 2.15, pivotY: 0.55, light: 1.2, display: 1, sweep: 3.5, sweepI: 0.7, pointer: 0, float: 0, fixedTime: FIXED, caseKey: 'titanium' }),
  )
  const strap = useRef(
    makeCtrl({ rotY: -0.55, rotX: -0.3, camZ: 6.6, pivotX: 0.3, pivotY: 3.1, light: 1.1, display: 1, sweep: 0, sweepI: 0.6, pointer: 0, float: 0, fixedTime: FIXED, caseKey: 'graphite', strapKey: 'stone' }),
  )

  return (
    <section id="design" data-nav="design" ref={root} className="relative bg-[#f4f2ec] text-obsidian">
      <div className="mx-auto max-w-[1600px] px-5 pb-20 pt-24 sm:px-8 sm:pb-24 sm:pt-28 lg:px-12 lg:pb-36 lg:pt-40">
        {/* headline */}
        <div className="grid gap-10 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-9">
            <p data-reveal className="eyebrow mb-8 !text-[#8a6d35]">
              Design story <span className="mx-2 text-obsidian/30">—</span> Industrial perfection
            </p>
            <h2
              data-lines
              className="display text-[clamp(2.6rem,7.6vw,7.4rem)] font-extralight leading-[0.96] tracking-[-0.035em]"
              aria-label="Beauty is not an extra. It is the engineering."
            >
              <span className="mask block" aria-hidden="true">
                <span data-line className="block">Beauty is not an extra.</span>
              </span>
              <span className="mask block" aria-hidden="true">
                <span data-line className="block">
                  It is the <em className="serif-it pr-1 font-light tracking-normal text-[#8a6d35]">engineering.</em>
                </span>
              </span>
            </h2>
          </div>
          <p data-reveal className="max-w-xs text-[0.95rem] leading-relaxed text-obsidian/65 lg:col-span-3 lg:justify-self-end">
            Every surface of AURELIS ONE is shaped by function first — then polished until the function becomes beautiful.
          </p>
        </div>

        <div data-hair className="hairline-dark mt-14 lg:mt-20" />

        {/* macro */}
        <figure className="mt-10 lg:mt-14">
          <div data-img className="relative">
            <div className="relative overflow-hidden">
              <div data-parallax="5" className="relative scale-[1.12]">
                <WatchStill ctrlRef={macro} ratio={2.1} width={1600} alt="Macro render of the AURELIS ONE titanium casing, chamfered edge and curved glass" className="w-full" />
              </div>
            </div>
            <Annotation x={30} y={26} label="Chamfered titanium edge" />
            <Annotation x={52} y={64} label="Curved glass, polished bezel" />
          </div>
          <figcaption className="mt-4 flex items-center justify-between text-[0.62rem] font-medium uppercase tracking-[0.3em] text-obsidian/55">
            <span>Fig. 01 — Case, macro</span>
            <span>Concept render</span>
          </figcaption>
        </figure>

        {/* asymmetric pair */}
        <div className="mt-24 grid gap-14 lg:mt-36 lg:grid-cols-12 lg:gap-10">
          <figure className="lg:col-span-5">
            <div data-img className="relative">
              <div className="overflow-hidden">
                <div data-parallax="6" className="scale-[1.14]">
                  <WatchStill ctrlRef={crown} ratio={0.8} width={1000} alt="Close-up render of the knurled digital crown with champagne accent ring" className="w-full" />
                </div>
              </div>
              <Annotation x={46} y={42} label="Knurled crown" />
            </div>
            <figcaption className="mt-4 text-[0.62rem] font-medium uppercase tracking-[0.3em] text-obsidian/55">Fig. 02 — Digital crown</figcaption>
          </figure>

          <div className="flex flex-col justify-between lg:col-span-6 lg:col-start-7 lg:pt-24">
            <div>
              <p data-reveal className="eyebrow mb-6 !text-[#8a6d35]">
                The crown
              </p>
              <h3 data-reveal className="display max-w-xl text-[clamp(1.9rem,3.6vw,3.4rem)] font-extralight leading-[1.04]">
                One precise gesture, finished by hand.
              </h3>
              <p data-reveal className="mt-6 max-w-md text-[0.98rem] leading-relaxed text-obsidian/65">
                Fine knurling gives the crown grip without noise. A single champagne ring marks the point where touch meets machine.
              </p>
            </div>

            <figure className="mt-16 lg:mt-24">
              <div data-img className="relative">
                <div className="overflow-hidden">
                  <div data-parallax="5" className="scale-[1.12]">
                    <WatchStill ctrlRef={strap} ratio={1.45} width={1300} alt="Render of the lug and ribbed strap connection in graphite with a stone strap" className="w-full" />
                  </div>
                </div>
                <Annotation x={22} y={38} label="Seamless lug" side="left" />
              </div>
              <figcaption className="mt-4 flex justify-between text-[0.62rem] font-medium uppercase tracking-[0.3em] text-obsidian/55">
                <span>Fig. 03 — Case & strap</span>
                <span>Graphite · Stone</span>
              </figcaption>
            </figure>
          </div>
        </div>

        {/* material notes */}
        <div className="mt-24 grid gap-px overflow-hidden bg-obsidian/15 sm:grid-cols-3 lg:mt-36">
          {[
            ['Case', 'Machined titanium form with chamfered edges — finish and grade to be confirmed.'],
            ['Glass', 'Curved cover with a polished bezel. Material specification to be confirmed.'],
            ['Strap', 'Fine-ribbed elastomer shown in three colourways. Final material to be confirmed.'],
          ].map(([t, d]) => (
            <div key={t} data-reveal className="bg-[#f4f2ec] p-7 lg:p-9">
              <p className="eyebrow !text-[#8a6d35]">{t}</p>
              <p className="mt-4 text-[0.95rem] leading-relaxed text-obsidian/70">{d}</p>
            </div>
          ))}
        </div>
        {/* finishes + design details */}
        <div className="mt-24 grid gap-14 lg:mt-36 lg:grid-cols-12 lg:gap-10">
          <div className="lg:col-span-5">
            <p data-reveal className="eyebrow mb-6 !text-[#8a6d35]">Finishes &amp; straps</p>
            <h3 data-reveal className="display text-[clamp(1.9rem,3.6vw,3.4rem)] font-extralight leading-[1.04]">Three cases. Three straps. One form.</h3>
            <p data-reveal className="mt-6 max-w-md text-[0.98rem] leading-relaxed text-obsidian/65">
              Colour changes, geometry does not. Choose the metal that suits you, then the strap that suits the day.
            </p>
            <div data-reveal className="mt-8 space-y-6">
              {[['Case', CASES], ['Strap', STRAPS]].map(([t, list]) => (
                <div key={t}>
                  <p className="mb-3 text-[0.62rem] font-medium uppercase tracking-[0.28em] text-obsidian/50">{t}</p>
                  <ul className="flex flex-wrap gap-2.5">
                    {list.map((o) => (
                      <li key={o.key} className="flex items-center gap-2.5 rounded-full border border-obsidian/15 py-1.5 pl-1.5 pr-4 text-[0.82rem] text-obsidian/80">
                        <span className="h-6 w-6 rounded-full ring-1 ring-obsidian/20" style={{ background: o.swatch }} />
                        {o.label}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
          <dl className="lg:col-span-7">
            <div data-hair className="hairline-dark" />
            {[
              ['Chamfered edge', 'A fine bevel runs the full perimeter of the case, catching light along every curve.'],
              ['Curved glass', 'Cover glass rises gently into a polished bezel so the display feels part of the case.'],
              ['Digital crown', 'Knurled for grip, finished with a single champagne ring as the one point of colour.'],
              ['Seamless lugs', 'The strap meets the case in one continuous line, with no visible gap or hardware.'],
              ['Ribbed strap', 'A fine rib pattern adds texture and flex for all-day comfort on the wrist.'],
              ['Quiet display', 'Dark, high-contrast faces keep time and rings readable at a glance.'],
            ].map(([k, v]) => (
              <div key={k}>
                <div data-reveal className="grid gap-1.5 py-5 sm:grid-cols-[10rem_1fr] sm:gap-8 lg:py-6">
                  <dt className="text-[0.68rem] font-medium uppercase tracking-[0.26em] text-obsidian/50">{k}</dt>
                  <dd className="text-[0.98rem] font-light leading-snug text-obsidian">{v}</dd>
                </div>
                <div data-hair className="hairline-dark" />
              </div>
            ))}
          </dl>
        </div>

        <p className="mt-10 text-[0.68rem] tracking-wide text-obsidian/45">
          Imagery is rendered live from the AURELIS ONE concept model. Material descriptions are design intent, not verified specifications.
        </p>
      </div>
    </section>
  )
}
