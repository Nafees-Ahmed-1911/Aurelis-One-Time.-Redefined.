import { useEffect, useMemo, useRef } from 'react'
import { Canvas, useFrame, useThree } from '@react-three/fiber'
import { Environment, Lightformer, RoundedBox, MeshReflectorMaterial } from '@react-three/drei'
import * as THREE from 'three'
import { CASES, STRAPS } from '../lib/watchConfig'
import { SCREEN_W, SCREEN_H, drawTransition } from '../lib/watchScreens'

/* ------------------------------------------------------------------ geometry
   The watch is built procedurally (no external model): a superellipse case with
   machined chamfers, polished bezel, curved-edge sapphire-style glass, knurled
   crown, lugs and a ribbed strap. Units are arbitrary; case width = 3.8.        */

const CASE_W = 3.8
const CASE_H = 4.6
const OPEN_W = 3.14
const OPEN_H = 3.94

function squircle(w, h, n = 5, seg = 168) {
  const s = new THREE.Shape()
  for (let i = 0; i <= seg; i++) {
    const a = (i / seg) * Math.PI * 2
    const c = Math.cos(a)
    const sn = Math.sin(a)
    const x = Math.sign(c) * Math.pow(Math.abs(c), 2 / n) * (w / 2)
    const y = Math.sign(sn) * Math.pow(Math.abs(sn), 2 / n) * (h / 2)
    i === 0 ? s.moveTo(x, y) : s.lineTo(x, y)
  }
  return s
}

function extrude(shape, depth, bevel, segs = 2) {
  const g = new THREE.ExtrudeGeometry(shape, {
    depth,
    bevelEnabled: true,
    bevelThickness: bevel,
    bevelSize: bevel,
    bevelOffset: -bevel,
    bevelSegments: segs,
    curveSegments: 1,
    steps: 1,
  })
  g.translate(0, 0, -depth / 2)
  return g
}

function knurled(r, len, teeth = 30) {
  const g = new THREE.CylinderGeometry(r, r, len, teeth * 4, 1, false)
  const p = g.attributes.position
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i)
    const z = p.getZ(i)
    const rad = Math.hypot(x, z)
    if (rad < 1e-4) continue
    const k = 1 + 0.05 * Math.cos(Math.atan2(z, x) * teeth)
    p.setX(i, x * k)
    p.setZ(i, z * k)
  }
  g.rotateZ(Math.PI / 2)
  g.computeVertexNormals()
  return g
}

function buildStrap(sign, short = false) {
  const base = [
    [2.45, -0.02],
    [3.3, -0.05],
    [4.15, -0.24],
    [4.95, -0.66],
    [5.6, -1.3],
    [6.0, -2.15],
  ]
  const pts = (short ? base.slice(0, 4) : base).map(([y, z]) => new THREE.Vector3(0, sign * y, z))
  const curve = new THREE.CatmullRomCurve3(pts, false, 'centripetal')
  const N = 72
  const cs = [
    [-1, -0.6],
    [-1, 0.6],
    [-0.93, 1],
    [0.93, 1],
    [1, 0.6],
    [1, -0.6],
    [0.93, -1],
    [-0.93, -1],
  ]
  const M = cs.length
  const pos = []
  const col = []
  const uv = []
  const idx = []
  const Z = new THREE.Vector3(0, 0, 1)
  for (let i = 0; i <= N; i++) {
    const s = i / N
    const p = curve.getPoint(s)
    const T = curve.getTangent(s)
    const Nrm = Z.clone().sub(T.clone().multiplyScalar(Z.dot(T))).normalize()
    const halfW = THREE.MathUtils.lerp(1.42, 1.26, s)
    const halfT = 0.15
    const f = short ? 1 - THREE.MathUtils.smoothstep(s, 0.05, 0.8) : 1 - THREE.MathUtils.smoothstep(s, 0.42, 1) * 0.94
    for (let k = 0; k < M; k++) {
      const [ax, an] = cs[k]
      pos.push(p.x + ax * halfW, p.y + Nrm.y * an * halfT, p.z + Nrm.z * an * halfT)
      col.push(f, f, f)
      uv.push(k / M, s * 7)
    }
  }
  for (let i = 0; i < N; i++) {
    for (let k = 0; k < M; k++) {
      const a = i * M + k
      const b = i * M + ((k + 1) % M)
      const c = (i + 1) * M + k
      const d = (i + 1) * M + ((k + 1) % M)
      idx.push(a, b, c, b, d, c)
    }
  }
  const g = new THREE.BufferGeometry()
  g.setAttribute('position', new THREE.Float32BufferAttribute(pos, 3))
  g.setAttribute('color', new THREE.Float32BufferAttribute(col, 3))
  g.setAttribute('uv', new THREE.Float32BufferAttribute(uv, 2))
  g.setIndex(idx)
  g.computeVertexNormals()
  return g
}

function strapBump() {
  const c = document.createElement('canvas')
  c.width = 64
  c.height = 128
  const x = c.getContext('2d')
  x.fillStyle = '#777'
  x.fillRect(0, 0, 64, 128)
  for (let y = 0; y < 128; y += 8) {
    const g = x.createLinearGradient(0, y, 0, y + 8)
    g.addColorStop(0, '#aaa')
    g.addColorStop(0.5, '#555')
    g.addColorStop(1, '#aaa')
    x.fillStyle = g
    x.fillRect(0, y, 64, 8)
  }
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  t.repeat.set(1, 2)
  return t
}

function glowTexture() {
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const x = c.getContext('2d')
  const g = x.createRadialGradient(64, 64, 0, 64, 64, 64)
  g.addColorStop(0, 'rgba(255,255,255,0.55)')
  g.addColorStop(0.45, 'rgba(255,255,255,0.16)')
  g.addColorStop(1, 'rgba(255,255,255,0)')
  x.fillStyle = g
  x.fillRect(0, 0, 128, 128)
  return new THREE.CanvasTexture(c)
}

/* ------------------------------------------------------------------- model */

function WatchModel({ ctrl, still }) {
  const geo = useMemo(() => {
    const caseShape = squircle(CASE_W, CASE_H)
    const bezelShape = squircle(CASE_W - 0.04, CASE_H - 0.04)
    bezelShape.holes.push(squircle(OPEN_W, OPEN_H))
    const disp = new THREE.ShapeGeometry(squircle(OPEN_W - 0.04, OPEN_H - 0.04, 5, 96), 1)
    const uvA = disp.attributes.uv
    const posA = disp.attributes.position
    for (let i = 0; i < uvA.count; i++) uvA.setXY(i, posA.getX(i) / (OPEN_W - 0.04) + 0.5, posA.getY(i) / (OPEN_H - 0.04) + 0.5)
    return {
      body: extrude(caseShape, 0.7, 0.1, 2),
      bezel: extrude(bezelShape, 0.05, 0.05, 3),
      glass: extrude(squircle(OPEN_W + 0.06, OPEN_H + 0.06), 0.02, 0.1, 6),
      disp,
      crown: knurled(0.27, 0.34),
      collar: new THREE.CylinderGeometry(0.31, 0.31, 0.1, 48).rotateZ(Math.PI / 2),
      cap: new THREE.CylinderGeometry(0.258, 0.258, 0.02, 48).rotateZ(Math.PI / 2),
      accent: new THREE.TorusGeometry(0.285, 0.02, 12, 64).rotateY(Math.PI / 2),
      top: buildStrap(1),
      bottom: buildStrap(-1),
      topS: buildStrap(1, true),
      bottomS: buildStrap(-1, true),
    }
  }, [])

  const tex = useMemo(() => {
    const canvas = document.createElement('canvas')
    canvas.width = SCREEN_W
    canvas.height = SCREEN_H
    const t = new THREE.CanvasTexture(canvas)
    t.colorSpace = THREE.SRGBColorSpace
    t.anisotropy = 8
    return { canvas, ctx: canvas.getContext('2d'), t }
  }, [])
  const bump = useMemo(strapBump, [])
  const glowTex = useMemo(glowTexture, [])

  const mats = useMemo(
    () => ({
      body: new THREE.MeshPhysicalMaterial({ color: '#b9bcc2', metalness: 1, roughness: 0.3 }),
      bezel: new THREE.MeshPhysicalMaterial({ color: '#b9bcc2', metalness: 1, roughness: 0.13 }),
      glass: new THREE.MeshPhysicalMaterial({
        color: '#000',
        metalness: 0,
        roughness: 0.02,
        transparent: true,
        opacity: 0.26,
        clearcoat: 1,
        clearcoatRoughness: 0,
        depthWrite: false,
      }),
      display: new THREE.MeshBasicMaterial({ map: tex.t, toneMapped: false }),
      glow: new THREE.MeshBasicMaterial({
        map: glowTex,
        color: '#d9bd82',
        transparent: true,
        opacity: 0,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
        toneMapped: false,
      }),
      strap: new THREE.MeshStandardMaterial({
        color: '#121315',
        roughness: 0.62,
        metalness: 0,
        vertexColors: true,
        bumpMap: bump,
        bumpScale: 0.7,
        side: THREE.DoubleSide,
      }),
      dark: new THREE.MeshStandardMaterial({ color: '#0b0b0c', roughness: 0.5, metalness: 0.3 }),
      gold: new THREE.MeshPhysicalMaterial({ color: '#c9a96a', metalness: 1, roughness: 0.2 }),
    }),
    [tex, bump, glowTex],
  )

  // dispose everything we created when the canvas goes away
  useEffect(
    () => () => {
      Object.values(geo).forEach((g) => g.dispose())
      Object.values(mats).forEach((m) => m.dispose())
      tex.t.dispose()
      bump.dispose()
      glowTex.dispose()
    },
    [geo, mats, tex, bump, glowTex],
  )

  const targets = useMemo(
    () => ({
      cases: Object.fromEntries(CASES.map((c) => [c.key, new THREE.Color(c.color)])),
      straps: Object.fromEntries(STRAPS.map((s) => [s.key, new THREE.Color(s.color)])),
    }),
    [],
  )
  const last = useRef(0)
  const first = useRef(true)
  const strapLong = useRef()
  const strapLong2 = useRef()
  const strapShort = useRef()
  const strapShort2 = useRef()

  useFrame((state, dt) => {
    const c = ctrl.current
    const k = first.current || still ? 1 : 1 - Math.exp(-dt * 5.5)
    first.current = false
    const caseCol = targets.cases[c.caseKey] || targets.cases.titanium
    mats.body.color.lerp(caseCol, k)
    mats.bezel.color.lerp(caseCol, k)
    mats.strap.color.lerp(targets.straps[c.strapKey] || targets.straps.black, k)
    const sh = !!c.shortStrap
    if (strapLong.current) {
      strapLong.current.visible = strapLong2.current.visible = !sh
      strapShort.current.visible = strapShort2.current.visible = sh
    }
    const env = c.light
    mats.body.envMapIntensity = 1.25 * env
    mats.bezel.envMapIntensity = 1.5 * env
    mats.gold.envMapIntensity = 1.3 * env
    mats.glass.envMapIntensity = 1.0 * env
    mats.strap.envMapIntensity = 0.9 * env
    mats.dark.envMapIntensity = 0.6 * env

    mats.display.color.setScalar(THREE.MathUtils.clamp(c.display, 0, 1.5))
    mats.glow.opacity = THREE.MathUtils.clamp(c.glow * Math.min(1, c.display), 0, 1) * 0.55

    const now = performance.now()
    if (c.display > 0.01 && (still || now - last.current > 38)) {
      last.current = now
      drawTransition(tex.ctx, c.screen, c.prevScreen, c.mix, c.fixedTime ?? Date.now())
      tex.t.needsUpdate = true
    }
  })

  const crownY = 0.58
  return (
    <group>
      {/* case + chamfered body */}
      <mesh geometry={geo.body} material={mats.body} />
      {/* polished bezel ring */}
      <mesh geometry={geo.bezel} material={mats.bezel} position={[0, 0, 0.4]} />
      {/* display + glass */}
      <mesh geometry={geo.disp} material={mats.display} position={[0, 0, 0.455]} renderOrder={1} />
      <mesh geometry={geo.glass} material={mats.glass} position={[0, 0, 0.455]} renderOrder={3} />
      <mesh position={[0, 0, 0.56]} material={mats.glow} renderOrder={4}>
        <planeGeometry args={[5.2, 6]} />
      </mesh>

      {/* digital crown */}
      <group position={[CASE_W / 2 - 0.02, crownY, 0]}>
        <mesh geometry={geo.collar} material={mats.bezel} position={[0.06, 0, 0]} />
        <mesh geometry={geo.accent} material={mats.gold} position={[0.14, 0, 0]} />
        <mesh geometry={geo.crown} material={mats.body} position={[0.33, 0, 0]} />
        <mesh geometry={geo.cap} material={mats.bezel} position={[0.505, 0, 0]} />
      </group>
      {/* side button */}
      <RoundedBox args={[0.2, 0.82, 0.28]} radius={0.07} smoothness={3} position={[CASE_W / 2 + 0.03, -0.72, 0]} material={mats.body} />

      {/* lugs */}
      <RoundedBox args={[3.02, 0.6, 0.64]} radius={0.14} smoothness={4} position={[0, CASE_H / 2 + 0.05, -0.04]} material={mats.body} />
      <RoundedBox args={[3.02, 0.6, 0.64]} radius={0.14} smoothness={4} position={[0, -CASE_H / 2 - 0.05, -0.04]} material={mats.body} />

      {/* strap */}
      <mesh ref={strapLong} geometry={geo.top} material={mats.strap} />
      <mesh ref={strapLong2} geometry={geo.bottom} material={mats.strap} />
      <mesh ref={strapShort} geometry={geo.topS} material={mats.strap} visible={false} />
      <mesh ref={strapShort2} geometry={geo.bottomS} material={mats.strap} visible={false} />

    </group>
  )
}

/* ---------------------------------------------------------------- lighting */

function Lighting({ kind }) {
  if (kind === 'rim') {
    return (
      <Environment resolution={256} frames={1}>
        <Lightformer form="rect" intensity={13} color="#fff4e0" position={[-5.5, 0, -4]} scale={[1.4, 10, 1]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={13} color="#dce6ff" position={[5.5, 0, -4]} scale={[1.4, 10, 1]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={2.2} color="#fff" position={[0, 6, -2]} scale={[8, 1.6, 1]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={0.9} color="#c9a96a" position={[0, -4, 4]} scale={[7, 1.5, 1]} target={[0, 0, 0]} />
        <Lightformer form="rect" intensity={0.07} color="#fff" position={[0, 0, 12]} scale={[26, 26, 1]} target={[0, 0, 0]} />
      </Environment>
    )
  }
  return (
    <Environment resolution={256} frames={1}>
      <Lightformer form="rect" intensity={3.4} color="#fff6e6" position={[0, 6, 3]} scale={[10, 3, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={2.4} color="#dfe8ff" position={[-6.5, 0.5, 2]} scale={[1.6, 10, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={3} color="#ffffff" position={[6.5, 1, 1.5]} scale={[1.3, 10, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={1.3} color="#c9a96a" position={[0, -5, 3]} scale={[8, 2, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={0.55} color="#ffffff" position={[0, 0, 12]} scale={[26, 26, 1]} target={[0, 0, 0]} />
      <Lightformer form="rect" intensity={1.6} color="#ffffff" position={[0, 2, -7]} scale={[9, 3, 1]} target={[0, 0, 0]} />
    </Environment>
  )
}

/* ------------------------------------------------------------ shared input */

const ptr = { x: 0, y: 0, sx: 0, sy: 0, bound: false }
function bindPointer() {
  if (ptr.bound || typeof window === 'undefined') return
  ptr.bound = true
  window.addEventListener(
    'pointermove',
    (e) => {
      if (e.pointerType === 'touch') return
      ptr.x = (e.clientX / window.innerWidth) * 2 - 1
      ptr.y = (e.clientY / window.innerHeight) * 2 - 1
    },
    { passive: true },
  )
}

/* --------------------------------------------------------------------- rig */

const FOV = 28
const TAN = Math.tan(THREE.MathUtils.degToRad(FOV / 2))

function Rig({ ctrl, drag, reflect, still, onStill }) {
  const outer = useRef()
  const rot = useRef()
  const floater = useRef()
  const inner = useRef()
  const light = useRef()
  const dragState = useRef({ on: false, x: 0, y: 0, yaw: 0, pitch: 0 })
  const { gl, camera, size, scene } = useThree()
  const frames = useRef(0)

  useEffect(() => {
    bindPointer()
    camera.lookAt(0, 0, 0)
  }, [camera])

  useEffect(() => {
    if (!drag) return
    const el = gl.domElement
    const s = dragState.current
    const down = (e) => {
      s.on = true
      s.x = e.clientX
      s.y = e.clientY
      el.setPointerCapture?.(e.pointerId)
    }
    const move = (e) => {
      if (!s.on) return
      s.yaw = THREE.MathUtils.clamp(s.yaw + (e.clientX - s.x) * 0.012, -1.4, 1.4)
      s.pitch = THREE.MathUtils.clamp(s.pitch + (e.clientY - s.y) * 0.006, -0.5, 0.5)
      s.x = e.clientX
      s.y = e.clientY
    }
    const up = () => (s.on = false)
    el.addEventListener('pointerdown', down)
    el.addEventListener('pointermove', move)
    el.addEventListener('pointerup', up)
    el.addEventListener('pointercancel', up)
    return () => {
      el.removeEventListener('pointerdown', down)
      el.removeEventListener('pointermove', move)
      el.removeEventListener('pointerup', up)
      el.removeEventListener('pointercancel', up)
    }
  }, [drag, gl])

  useFrame((state, dt) => {
    const c = ctrl.current
    const t = state.clock.elapsedTime
    const d3 = Math.min(dt, 0.05)
    ptr.sx += (ptr.x - ptr.sx) * Math.min(1, d3 * 3)
    ptr.sy += (ptr.y - ptr.sy) * Math.min(1, d3 * 3)
    const ds = dragState.current
    if (!ds.on) {
      ds.yaw *= 1 - Math.min(1, d3 * 2.4)
      ds.pitch *= 1 - Math.min(1, d3 * 2.4)
    }

    // camera distance — keeps the product framed on narrow screens
    const aspect = size.width / size.height
    const minW = 7.6 * (c.camZ / 17)
    const dist = Math.max(c.camZ, minW / (2 * TAN * aspect))
    camera.position.set(0, 0, dist)
    camera.near = 0.5
    camera.far = 80
    camera.updateProjectionMatrix()
    const visH = 2 * dist * TAN
    const visW = visH * aspect

    outer.current.position.set(c.shiftX * visW, c.shiftY * visH, 0)
    outer.current.scale.setScalar(c.scale)
    rot.current.rotation.set(
      c.rotX - ptr.sy * 0.09 * c.pointer + ds.pitch,
      c.rotY + ptr.sx * 0.2 * c.pointer + ds.yaw,
      c.rotZ,
      'YXZ',
    )
    floater.current.position.y = Math.sin(t * 0.9) * 0.14 * c.float
    floater.current.rotation.z = Math.sin(t * 0.55) * 0.016 * c.float
    inner.current.position.set(-c.pivotX, -c.pivotY, 0)

    light.current.position.set(c.sweep, 1.2, 3.8)
    light.current.intensity = c.sweepI * 90

    if (still) {
      frames.current++
      if (frames.current === 6) {
        gl.render(scene, camera)
        onStill?.(gl.domElement.toDataURL('image/webp', 0.92))
      }
    }
  })

  return (
    <>
      <pointLight ref={light} color="#fff3dc" distance={40} decay={2} intensity={0} />
      <group ref={outer}>
        <group ref={rot}>
          <group ref={floater}>
            <group ref={inner}>
              <WatchModel ctrl={ctrl} still={still} />
            </group>
          </group>
        </group>
      </group>
      {reflect && (
        <mesh rotation-x={-Math.PI / 2} position={[0, -4.25, -0.6]}>
          <planeGeometry args={[40, 30]} />
          <MeshReflectorMaterial
            mirror={1}
            blur={[380, 110]}
            resolution={512}
            mixBlur={1.2}
            mixStrength={14}
            roughness={1}
            depthScale={0.6}
            minDepthThreshold={0.4}
            maxDepthThreshold={1.3}
            color="#050506"
            metalness={0.4}
          />
        </mesh>
      )}
    </>
  )
}

/* ------------------------------------------------------------------ export */

export default function Watch3D({
  ctrl,
  lighting = 'studio',
  reflect = false,
  drag = false,
  active = true,
  still = false,
  onStill,
  dpr,
  className = '',
  onReady,
}) {
  const small = typeof window !== 'undefined' && window.innerWidth < 768
  return (
    <Canvas
      className={className}
      style={{ touchAction: drag ? 'pan-y' : 'auto' }}
      dpr={still ? 1 : dpr || (small ? [1, 1.5] : [1, 1.75])}
      frameloop={active ? 'always' : 'never'}
      camera={{ fov: FOV, position: [0, 0, 16], near: 0.5, far: 80 }}
      gl={{ antialias: true, alpha: true, powerPreference: 'high-performance', preserveDrawingBuffer: false }}
      onCreated={({ gl }) => {
        gl.toneMapping = THREE.ACESFilmicToneMapping
        gl.toneMappingExposure = 1.05
        onReady?.()
      }}
    >
      <Lighting kind={lighting} />
      <Rig ctrl={ctrl} drag={drag} reflect={reflect} still={still} onStill={onStill} />
    </Canvas>
  )
}
