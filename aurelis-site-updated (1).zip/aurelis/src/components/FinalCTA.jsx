import { useLayoutEffect, useRef } from 'react'
import { ArrowRight } from 'lucide-react'
import WatchStage from './WatchStage'
import { gsap } from '../lib/gsap'
import { makeCtrl } from '../lib/watchConfig'
import { useApp, scrollToId } from '../context'
import { useScrollAnimations } from '../hooks/useScrollAnimations'
import { prefersReducedMotion } from '../hooks/useEnv'

export default function FinalCTA() {
  const root = useRef(null)
  const { openReserve, config } = useApp()
  const ctrl = useRef(
    makeCtrl({ rotY: -0.4, rotX: 0.06, camZ: 23, light: 1.1, display: 1, float: 1, pointer: 1, glow: 0.4, shiftY: -0.08, shortStrap: true, caseKey: config.case, strapKey: config.strap, screen: { type: 'face', key: config.face } }),
  )
  useScrollAnimations(root)

  useLayoutEffect(() => {
    const c = ctrl.current
    c.caseKey = config.case
    c.strapKey = config.strap
    c.screen = { type: 'face', key: config.face }
    if (prefersReducedMotion()) return
    // slow light drifting across the titanium
    const tw = gsap.fromTo(c, { sweep: -5, sweepI: 0.9 }, { sweep: 5, duration: 7, ease: 'sine.inOut', repeat: -1, repeatDelay: 2.5 })
    const rot = gsap.to(c, { rotY: -0.15, duration: 9, ease: 'sine.inOut', yoyo: true, repeat: -1 })
    return () => {
      tw.kill()
      rot.kill()
    }
  }, [config])

  return (
    <section id="reserve" ref={root} className="relative min-h-[100svh] overflow-hidden bg-obsidian pb-[calc(var(--tabbar)+4rem)] pt-28 lg:pb-24 lg:pt-36" aria-labelledby="final-title">
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="absolute left-1/2 top-[38%] h-[70%] w-[80%] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(201,169,106,0.11),transparent)]" />
      </div>
      <WatchStage ctrl={ctrl} reflect lighting="studio" className="absolute inset-0 z-[1] pointer-events-none" label="AURELIS ONE floating above a reflective surface" />
      <div className="vignette absolute inset-0 z-[2]" aria-hidden="true" />

      <div className="relative z-[3] mx-auto flex min-h-[calc(100svh-13rem)] max-w-[1400px] flex-col items-center justify-between px-5 text-center sm:px-8">
        <div>
          <p data-reveal className="eyebrow mb-6">
            Meet AURELIS ONE.
          </p>
          <h2 id="final-title" data-lines className="display text-[clamp(2.3rem,7.4vw,7.2rem)] font-extralight text-ivory" aria-label="The future looks better on you.">
            <span className="mask block" aria-hidden="true">
              <span data-line className="block">THE FUTURE LOOKS</span>
            </span>
            <span className="mask block" aria-hidden="true">
              <span data-line className="block text-champagne">BETTER ON YOU.</span>
            </span>
          </h2>
        </div>

        <div data-reveal className="flex flex-col items-center gap-6 pt-24 sm:flex-row">
          <button type="button" className="btn btn-primary" onClick={() => openReserve(1)}>
            Reserve Your Watch <ArrowRight size={14} />
          </button>
          <a
            href="#story"
            onClick={(e) => {
              e.preventDefault()
              scrollToId('story')
            }}
            className="link-u text-[0.72rem] font-medium uppercase tracking-[0.22em] text-ivory/75 hover:text-ivory"
          >
            Explore Every Detail
          </a>
        </div>
      </div>
    </section>
  )
}
