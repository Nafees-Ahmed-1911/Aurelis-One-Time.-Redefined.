import { useRef } from 'react'
import { useScrollAnimations } from '../hooks/useScrollAnimations'

const SPECS = [
  ['Display', '[ Panel type ] · [ Diagonal ] · [ Resolution ] · [ Peak brightness ]'],
  ['Case materials', 'Titanium · Graphite finish · Champagne finish (colour options in design concept)'],
  ['Dimensions', '[ Width × Height × Thickness ]'],
  ['Weight', '[ Case weight ] · [ With strap ]'],
  ['Sensors', '[ Heart-rate ] · [ Motion ] · [ Temperature ] · [ Others to be confirmed ]'],
  ['Connectivity', '[ Bluetooth ] · [ Wi-Fi ] · [ Cellular / NFC options ]'],
  ['Battery', '[ Capacity ] · [ Typical life ]'],
  ['Charging', '[ Method ] · [ Time to full charge ]'],
  ['Compatibility', '[ iOS versions ] · [ Android versions ]'],
]

export default function Specifications() {
  const root = useRef(null)
  useScrollAnimations(root)
  return (
    <section id="specs" data-nav="specs" ref={root} className="relative bg-[#f4f2ec] py-20 text-obsidian sm:py-28 lg:py-40">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="grid gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <p data-reveal className="eyebrow mb-6 !text-[#8a6d35]">
              Technical specifications
            </p>
            <h2 data-lines className="display text-[clamp(2.4rem,5.4vw,5rem)] font-extralight leading-[0.98]" aria-label="The details, in detail.">
              <span className="mask block" aria-hidden="true">
                <span data-line className="block">The details,</span>
              </span>
              <span className="mask block" aria-hidden="true">
                <span data-line className="serif-it block text-[#8a6d35]">in detail.</span>
              </span>
            </h2>
            <p data-reveal className="mt-8 max-w-sm rounded-2xl border border-obsidian/15 p-5 text-[0.85rem] leading-relaxed text-obsidian/65">
              <strong className="font-medium text-obsidian">Placeholder data.</strong> Bracketed values will be replaced when final product specifications are released. Nothing on this page is a verified claim.
            </p>
          </div>

          <dl className="lg:col-span-7">
            <div data-hair className="hairline-dark" />
            {SPECS.map(([k, v]) => (
              <div key={k}>
                <div data-reveal className="grid gap-2 py-6 sm:grid-cols-[11rem_1fr] sm:gap-8 lg:py-7">
                  <dt className="text-[0.68rem] font-medium uppercase tracking-[0.28em] text-obsidian/50">{k}</dt>
                  <dd className="text-[1.02rem] font-light leading-snug text-obsidian">{v}</dd>
                </div>
                <div data-hair className="hairline-dark" />
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  )
}
