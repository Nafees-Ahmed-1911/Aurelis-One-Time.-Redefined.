export default function Credit({ className = '' }) {
  return (
    <p className={className}>
      Crafted with precision by{' '}
      <a
        href="https://nafeesahmed.tech"
        target="_blank"
        rel="noopener noreferrer"
        className="link-u text-champagne transition-colors hover:text-ivory"
      >
        Mohm&apos;d Nafees
      </a>
    </p>
  )
}
