import { useLayoutEffect } from 'react'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { prefersReducedMotion } from './useEnv'

/**
 * Declarative scroll reveals for everything inside `rootRef`:
 *  [data-reveal]        fade + rise, batched so simultaneous entries stagger
 *  [data-lines]         children `.mask > [data-line]` slide up from a clip mask
 *  [data-hair]          hairline draws left → right
 *  [data-img]           clip-path image reveal (inner [data-parallax] drifts subtly)
 * Everything is reverted on unmount.
 */
export function useScrollAnimations(rootRef, deps = []) {
  useLayoutEffect(() => {
    const root = rootRef.current
    if (!root) return
    if (prefersReducedMotion()) return

    const ctx = gsap.context(() => {
      const reveals = gsap.utils.toArray('[data-reveal]', root)
      if (reveals.length) {
        gsap.set(reveals, { autoAlpha: 0, y: 34 })
        ScrollTrigger.batch(reveals, {
          start: 'top 90%',
          once: true,
          onEnter: (batch) =>
            gsap.to(batch, { autoAlpha: 1, y: 0, duration: 1.1, ease: 'power3.out', stagger: 0.11, overwrite: true }),
        })
      }

      gsap.utils.toArray('[data-lines]', root).forEach((group) => {
        const lines = group.querySelectorAll('[data-line]')
        gsap.set(lines, { yPercent: 108 })
        ScrollTrigger.create({
          trigger: group,
          start: 'top 88%',
          once: true,
          onEnter: () =>
            gsap.to(lines, { yPercent: 0, duration: 1.25, ease: 'power4.out', stagger: 0.12 }),
        })
      })

      gsap.utils.toArray('[data-hair]', root).forEach((h) => {
        gsap.set(h, { scaleX: 0 })
        ScrollTrigger.create({
          trigger: h,
          start: 'top 94%',
          once: true,
          onEnter: () => gsap.to(h, { scaleX: 1, duration: 1.4, ease: 'power3.inOut' }),
        })
      })

      gsap.utils.toArray('[data-img]', root).forEach((box) => {
        gsap.set(box, { clipPath: 'inset(0% 0% 100% 0%)' })
        ScrollTrigger.create({
          trigger: box,
          start: 'top 85%',
          once: true,
          onEnter: () =>
            gsap.to(box, { clipPath: 'inset(0% 0% 0% 0%)', duration: 1.6, ease: 'power4.inOut' }),
        })
        const inner = box.querySelector('[data-parallax]')
        if (inner) {
          const amt = parseFloat(inner.dataset.parallax) || 6
          gsap.fromTo(
            inner,
            { yPercent: -amt },
            {
              yPercent: amt,
              ease: 'none',
              scrollTrigger: { trigger: box, start: 'top bottom', end: 'bottom top', scrub: true },
            },
          )
        }
      })
    }, root)

    return () => ctx.revert()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps)
}
