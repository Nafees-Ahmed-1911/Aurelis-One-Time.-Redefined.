import { useCallback, useEffect, useMemo, useState } from 'react'
import { AppContext } from './context'
import { DEFAULT_CONFIG } from './lib/watchConfig'
import { ScrollTrigger } from './lib/gsap'
import { prefersReducedMotion } from './hooks/useEnv'
import Navbar from './components/Navbar'
import IntroLoader from './components/IntroLoader'
import HeroSection from './components/HeroSection'
import ScrollWatchExperience from './components/ScrollWatchExperience'
import DesignStory from './components/DesignStory'
import FeaturesSection from './components/FeaturesSection'
import CampaignSection from './components/CampaignSection'
import WatchCustomizer from './components/WatchCustomizer'
import Specifications from './components/Specifications'
import FinalCTA from './components/FinalCTA'
import Footer from './components/Footer'
import ReservationModal from './components/ReservationModal'

export default function App() {
  const [introDone, setIntroDone] = useState(() => prefersReducedMotion())
  const [config, setConfig] = useState(DEFAULT_CONFIG)
  const [reserve, setReserve] = useState({ open: false, step: 1 })

  const openReserve = useCallback((step = 1) => setReserve({ open: true, step: typeof step === 'number' ? step : 1 }), [])
  const closeReserve = useCallback(() => setReserve((r) => ({ ...r, open: false })), [])
  const setStep = useCallback((step) => setReserve((r) => ({ ...r, step })), [])

  useEffect(() => {
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual'
    window.scrollTo(0, 0)
    const refresh = () => ScrollTrigger.refresh()
    window.addEventListener('load', refresh)
    document.fonts?.ready.then(refresh)
    return () => window.removeEventListener('load', refresh)
  }, [])

  const value = useMemo(() => ({ config, setConfig, openReserve, introDone }), [config, openReserve, introDone])

  return (
    <AppContext.Provider value={value}>
      <a href="#main" className="skip-link">
        Skip to content
      </a>
      <Navbar />
      <main id="main">
        <HeroSection />
        <ScrollWatchExperience />
        <DesignStory />
        <FeaturesSection />
        <CampaignSection />
        <WatchCustomizer />
        <Specifications />
        <FinalCTA />
      </main>
      <Footer />
      <ReservationModal open={reserve.open} step={reserve.step} setStep={setStep} onClose={closeReserve} />
      {!introDone && <IntroLoader onDone={() => setIntroDone(true)} />}
    </AppContext.Provider>
  )
}
