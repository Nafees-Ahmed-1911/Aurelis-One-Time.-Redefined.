/** Splits text into masked characters ([data-char]) for GSAP stagger reveals; screen readers get the whole string. */
export default function SplitChars({ text, className = '' }) {
  return (
    <span className={className} aria-label={text}>
      {text.split('').map((ch, i) => (
        <span key={i} className="char-wrap" aria-hidden="true">
          <span className="char" data-char>
            {ch === ' ' ? ' ' : ch}
          </span>
        </span>
      ))}
    </span>
  )
}
