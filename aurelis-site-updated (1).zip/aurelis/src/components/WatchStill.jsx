import { lazy, Suspense, useEffect, useRef, useState } from 'react'
import { hasWebGL, useInView } from '../hooks/useEnv'

const Watch3D = lazy(() => import('./Watch3D'))

// Render stills one at a time so we never hold several GL contexts at once.
let tail = Promise.resolve()
function acquire() {
  let release
  const mine = new Promise((r) => (release = r))
  const wait = tail
  tail = wait.then(() => mine)
  return wait.then(() => release)
}

/**
 * Renders the real 3D model once from a chosen camera, captures the frame to an image,
 * then tears the WebGL context down. Used for the editorial "macro" imagery.
 * `ratio` is width / height.
 */
export default function WatchStill({ ctrlRef, alt, className = '', ratio = 0.8, width = 1100 }) {
  const box = useRef(null)
  const near = useInView(box, '700px')
  const [release, setRelease] = useState(null)
  const [url, setUrl] = useState(null)
  const started = useRef(false)
  const height = Math.round(width / ratio)

  useEffect(() => {
    if (!near || started.current || !hasWebGL()) return
    started.current = true
    let timer
    acquire().then((rel) => {
      timer = setTimeout(rel, 10000) // never stall the queue
      setRelease(() => () => {
        clearTimeout(timer)
        rel()
      })
    })
  }, [near])

  return (
    <div ref={box} className={`relative overflow-hidden bg-[#070708] ${className}`} style={{ aspectRatio: String(ratio) }}>
      {url ? (
        <img src={url} alt={alt} className="absolute inset-0 h-full w-full object-cover" loading="lazy" decoding="async" />
      ) : (
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_40%,#1b1c20,#070708_70%)]" role="img" aria-label={alt} />
      )}
      {release && !url && (
        <div className="pointer-events-none fixed left-0 top-0 -z-10 opacity-0" style={{ width, height }} aria-hidden="true">
          <Suspense fallback={null}>
            <Watch3D
              ctrl={ctrlRef}
              still
              onStill={(data) => {
                setUrl(data)
                release()
              }}
              className="!absolute inset-0"
            />
          </Suspense>
        </div>
      )}
    </div>
  )
}
