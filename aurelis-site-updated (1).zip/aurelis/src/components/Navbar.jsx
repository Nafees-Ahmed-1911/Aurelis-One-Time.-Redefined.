import { useEffect, useLayoutEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Gem, House, Menu, Shapes, SlidersHorizontal, Sparkles, X } from 'lucide-react'
import Credit from './Credit'
import Logo from './Logo'
import { useApp, scrollToId } from '../context'
import { gsap } from '../lib/gsap'
import { prefersReducedMotion } from '../hooks/useEnv'

const LINKS = [
  { id: 'overview', label: 'Overview' },
  { id: 'design', label: 'Design' },
  { id: 'features', label: 'Features' },
  { id: 'technology', label: 'Technology' },
  { id: 'specs', label: 'Specifications' },
]

const TABS = [
  { id: 'overview', label: 'Home', Icon: House },
  { id: 'design', label: 'Design', Icon: Gem },
  { id: 'features', label: 'Features', Icon: Sparkles },
  { id: 'customize', label: 'Customise', Icon: SlidersHorizontal },
  { id: 'specs', label: 'Specs', Icon: Shapes },
]

export default function Navbar() {
  const { openReserve, introDone } = useApp()
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)
  const [active, setActive] = useState('overview')
  const bar = useRef(null)
  const menuBtn = useRef(null)
  const menuOpen = useRef(false)
  menuOpen.current = open

  useLayoutEffect(() => {
    if (prefersReducedMotion()) return
    gsap.set(bar.current, { yPercent: -100, autoAlpha: 0 })
  }, [])
  useEffect(() => {
    if (!introDone) return
    if (prefersReducedMotion()) return
    gsap.to(bar.current, { yPercent: 0, autoAlpha: 1, duration: 1.1, ease: 'power3.out', delay: 0.9 })
  }, [introDone])

  useEffect(() => {
    let last = window.scrollY
    let hidden = false
    const on = () => {
      const y = window.scrollY
      setScrolled(y > 40)
      if (!introDone || prefersReducedMotion() || !window.matchMedia('(max-width: 1023px)').matches) {
        last = y
        return
      }
      const dy = y - last
      if (Math.abs(dy) < 8) return
      const shouldHide = dy > 0 && y > 140 && !menuOpen.current
      if (shouldHide !== hidden) {
        hidden = shouldHide
        gsap.to(bar.current, { yPercent: shouldHide ? -100 : 0, duration: 0.45, ease: 'power3.out', overwrite: 'auto' })
      }
      last = y
    }
    on()
    window.addEventListener('scroll', on, { passive: true })
    return () => window.removeEventListener('scroll', on)
  }, [introDone])

  // active-section tracking
  useEffect(() => {
    const els = document.querySelectorAll('[data-nav]')
    if (!els.length) return
    const seen = new Map()
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => seen.set(e.target, e.isIntersecting ? e.intersectionRatio : 0))
        let best = null
        let bestV = 0
        seen.forEach((v, el) => {
          if (v > bestV) {
            bestV = v
            best = el.dataset.nav
          }
        })
        if (best) setActive(best)
      },
      { threshold: [0, 0.2, 0.4, 0.6, 0.8, 1], rootMargin: '-30% 0px -30% 0px' },
    )
    els.forEach((el) => io.observe(el))
    return () => io.disconnect()
  }, [])

  // lock scroll + Escape for the mobile menu
  useEffect(() => {
    if (!open) return
    const prev = document.documentElement.style.overflow
    document.documentElement.style.overflow = 'hidden'
    const key = (e) => e.key === 'Escape' && (setOpen(false), menuBtn.current?.focus())
    window.addEventListener('keydown', key)
    return () => {
      document.documentElement.style.overflow = prev
      window.removeEventListener('keydown', key)
    }
  }, [open])

  const go = (id) => (e) => {
    e.preventDefault()
    setOpen(false)
    // wait a frame so the overflow lock is released before measuring/scrolling
    requestAnimationFrame(() => setTimeout(() => scrollToId(id), 30))
  }

  return (
    <>
      <header
        ref={bar}
        className={`fixed inset-x-0 top-0 z-50 transition-[background-color,backdrop-filter,border-color] duration-700 ${
          scrolled || open
            ? 'border-b border-white/[0.07] bg-[#060607]/70 backdrop-blur-xl'
            : 'border-b border-transparent bg-transparent'
        }`}
      >
        <nav aria-label="Primary" className="mx-auto flex h-[68px] max-w-[1600px] items-center justify-between px-5 sm:px-8 lg:px-12">
          <a href="#overview" onClick={go('overview')} aria-label="AURELIS — back to top" className="text-ivory">
            <Logo />
          </a>

          <ul className="hidden items-center gap-10 lg:flex">
            {LINKS.map((l) => (
              <li key={l.id}>
                <a
                  href={`#${l.id}`}
                  onClick={go(l.id)}
                  aria-current={(active === 'customize' ? 'technology' : active) === l.id ? 'true' : undefined}
                  className="link-u text-[0.7rem] font-normal uppercase tracking-[0.22em] text-ivory/75 transition-colors hover:text-ivory aria-[current=true]:text-ivory"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-3">
            <button type="button" onClick={() => openReserve()} className="btn btn-primary btn-sm">
              Pre-order
            </button>
            <button
              ref={menuBtn}
              type="button"
              className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-ivory lg:hidden"
              aria-label={open ? 'Close menu' : 'Open menu'}
              aria-expanded={open}
              aria-controls="mobile-menu"
              onClick={() => setOpen((o) => !o)}
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </nav>
      </header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            key="menu"
            initial={{ clipPath: 'inset(0 0 100% 0)' }}
            animate={{ clipPath: 'inset(0 0 0% 0)' }}
            exit={{ clipPath: 'inset(0 0 100% 0)' }}
            transition={{ duration: 0.7, ease: [0.76, 0, 0.24, 1] }}
            className="fixed inset-0 z-40 flex flex-col justify-center overflow-y-auto bg-[#060607] px-8 pb-[calc(var(--tabbar)+1.5rem)] pt-24 lg:hidden"
          >
            <ul className="space-y-2">
              {LINKS.map((l, i) => (
                <motion.li
                  key={l.id}
                  initial={{ opacity: 0, y: 24 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 + i * 0.07, duration: 0.7, ease: [0.2, 0.7, 0.2, 1] }}
                >
                  <a
                    href={`#${l.id}`}
                    onClick={go(l.id)}
                    className="flex items-baseline gap-4 border-b border-white/10 py-4 text-[2.1rem] font-extralight tracking-tight text-ivory"
                  >
                    <span className="w-7 text-[0.65rem] tracking-[0.3em] text-champagne">0{i + 1}</span>
                    {l.label}
                  </a>
                </motion.li>
              ))}
            </ul>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.7 }}
              className="mt-10"
            >
              <button
                type="button"
                className="btn btn-primary w-full"
                onClick={() => {
                  setOpen(false)
                  openReserve()
                }}
              >
                Pre-order AURELIS ONE
              </button>
              <Credit className="mt-8 text-center text-[0.68rem] uppercase tracking-[0.2em] text-ivory/45" />
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* app-style bottom tab bar (mobile / tablet only) */}
      {introDone && (
        <nav
          aria-label="Quick navigation"
          className="tabbar fixed inset-x-0 bottom-0 z-[45] border-t border-white/[0.08] bg-[#060607]/80 pb-[env(safe-area-inset-bottom,0px)] backdrop-blur-xl lg:hidden"
        >
          <ul className="mx-auto grid h-[4.1rem] max-w-xl grid-cols-5">
            {TABS.map(({ id, label, Icon }) => {
              const on = active === id || (id === 'features' && active === 'technology')
              return (
                <li key={id}>
                  <a
                    href={`#${id}`}
                    onClick={go(id)}
                    aria-current={on ? 'true' : undefined}
                    className={`relative flex h-full flex-col items-center justify-center gap-1 text-[0.6rem] font-medium tracking-[0.08em] transition-colors duration-300 active:scale-95 ${
                      on ? 'text-champagne' : 'text-ivory/50'
                    }`}
                  >
                    <span className={`absolute top-0 h-[2px] rounded-full bg-champagne transition-all duration-500 ${on ? 'w-8 opacity-100' : 'w-0 opacity-0'}`} />
                    <Icon size={20} strokeWidth={on ? 1.8 : 1.4} aria-hidden="true" />
                    {label}
                  </a>
                </li>
              )
            })}
          </ul>
        </nav>
      )}
    </>
  )
}
