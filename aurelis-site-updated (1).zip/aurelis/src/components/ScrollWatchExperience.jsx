import { useLayoutEffect, useRef } from 'react'
import WatchStage from './WatchStage'
import { gsap } from '../lib/gsap'
import { makeCtrl } from '../lib/watchConfig'
import { prefersReducedMotion, useReducedMotion } from '../hooks/useEnv'

const SCENES = [
  {
    n: '01',
    kicker: 'The silhouette',
    title: 'Every detail. Intentional.',
    body: 'From darkness, a single form — cut from one continuous idea and refined until nothing is left to remove.',
    side: 'left',
  },
  {
    n: '02',
    kicker: 'The rotation',
    title: 'Crafted beyond expectation.',
    body: 'Turn it and the case reveals itself: a machined crown, chamfered edges, a surface that holds the light.',
    side: 'right',
  },
  {
    n: '03',
    kicker: 'The display',
    title: 'Intelligence at a glance.',
    body: 'Time, rhythm and rings on a refined digital dial — composed so the essential reads first.',
    side: 'left',
  },
  {
    n: '04',
    kicker: 'The materials',
    title: 'Precision in every millimeter.',
    body: 'Polished edges. Curved glass. A knurled crown with a champagne ring. Light travels across all of it.',
    side: 'right',
  },
  {
    n: '05',
    kicker: 'The transformation',
    title: 'Made to move with you.',
    body: 'Now back in the light, complete — ready for the wrist, and for everything the day asks of it.',
    side: 'center',
  },
]

const sideClass = {
  left: 'lg:left-[6vw] lg:top-1/2 lg:-translate-y-1/2 lg:w-[min(30rem,38vw)]',
  right: 'lg:right-[6vw] lg:top-1/2 lg:-translate-y-1/2 lg:w-[min(30rem,38vw)]',
  center: 'lg:left-1/2 lg:-translate-x-1/2 lg:bottom-[7svh] lg:w-[min(36rem,60vw)] lg:text-center',
}

export default function ScrollWatchExperience() {
  const root = useRef(null)
  const reduce = useReducedMotion()
  const ctrl = useRef(
    makeCtrl({
      rotY: -0.25,
      rotX: 0.08,
      camZ: 26,
      light: 0.05,
      display: 0,
      sweepI: 0,
      pointer: 0.6,
      float: 0.5,
      screen: { type: 'face', key: 'digital' },
    }),
  )

  useLayoutEffect(() => {
    if (prefersReducedMotion() || reduce) {
      Object.assign(ctrl.current, { rotY: -0.5, rotX: 0.12, camZ: 15, light: 1, display: 1, glow: 0.3 })
      return
    }
    const c = ctrl.current
    const mm = gsap.matchMedia()
    const ctx = gsap.context(() => {
      mm.add({ desktop: '(min-width: 1024px)', mobile: '(max-width: 1023px)' }, (m) => {
        const D = m.conditions.desktop
        // horizontal / vertical placement as fractions of the visible frame
        const X = D ? 0.17 : 0
        const Y = D ? 0 : 0.17
        gsap.set(c, {
          rotY: -0.25,
          rotX: 0.08,
          camZ: 26,
          light: 0.05,
          display: 0,
          glow: 0,
          sweepI: 0,
          pivotX: 0,
          pivotY: 0,
          shiftX: X,
          shiftY: Y,
        })
        const texts = gsap.utils.toArray('[data-scene]', root.current)
        gsap.set(texts, { autoAlpha: 0, y: 42 })

        const tl = gsap.timeline({
          defaults: { ease: 'power2.inOut' },
          scrollTrigger: {
            trigger: root.current,
            start: 'top top',
            end: '+=560%',
            scrub: 1,
            pin: true,
            anticipatePin: 1,
            invalidateOnRefresh: true,
          },
        })

        // Scene 1 — silhouette emerges, camera approaches
        tl.to(c, { light: 0.95, camZ: 17, rotY: -0.1, sweepI: 1, duration: 1 }, 0)
          .fromTo(c, { sweep: -5 }, { sweep: 5, duration: 1, ease: 'none' }, 0)
          .to(c, { sweepI: 0.2, duration: 0.4 }, 0.7)
        // Scene 2 — rotate to three-quarter, crown revealed, graphite shift
        tl.to(c, { rotY: -0.95, rotX: 0.16, shiftX: -X * 1.25, camZ: 18, duration: 1 }, 1)
        // Scene 3 — camera to the display; it illuminates
        tl.to(c, { rotY: 0, rotX: 0, shiftX: X * 1.25, camZ: 9.8, duration: 1 }, 2)
          .to(c, { display: 1.05, glow: 0.8, duration: 0.75, ease: 'power1.in' }, 2.15)
          .to(c, { glow: 0.3, duration: 0.25 }, 2.9)
        // Scene 4 — materials close-up: crown, edge, glass
        tl.to(c, { rotY: -0.72, rotX: 0.2, pivotX: 1.55, pivotY: 0.9, shiftX: D ? -0.2 : 0, camZ: 8.6, display: 0.55, duration: 1 }, 3)
          .fromTo(c, { sweep: -5, sweepI: 1.6 }, { sweep: 5, duration: 0.9, ease: 'none' }, 3.05)
          .to(c, { sweepI: 0.2, duration: 0.2 }, 3.95)
        // Scene 5 — return to hero angle, centred, lighting intensifies
        tl.to(c, { rotY: -0.5, rotX: 0.12, pivotX: 0, pivotY: 0, shiftX: 0, shiftY: D ? 0.06 : Y, camZ: 17, light: 1.35, display: 1, glow: 0.45, duration: 1 }, 4)
        tl.to({}, { duration: 0.25 }) // brief hold

        // copy
        texts.forEach((el, i) => {
          const last = i === texts.length - 1
          tl.to(el, { autoAlpha: 1, y: 0, duration: 0.28, ease: 'power3.out' }, i + 0.12)
          if (!last) tl.to(el, { autoAlpha: 0, y: -34, duration: 0.2, ease: 'power2.in' }, i + 0.78)
        })

        // backdrop + progress
        tl.to('[data-sx-glow]', { opacity: 1, duration: 1.2, ease: 'none' }, 1)
          .to('[data-sx-glow]', { opacity: 0.45, duration: 1, ease: 'none' }, 3)
          .to('[data-sx-glow]', { opacity: 1, duration: 1, ease: 'none' }, 4)
        tl.fromTo('[data-sx-progress]', { scaleY: 0 }, { scaleY: 1, ease: 'none', duration: 5.25 }, 0)
        tl.to('[data-sx-bg]', { backgroundColor: '#17181b', ease: 'none', duration: 1 }, 1)
          .to('[data-sx-bg]', { backgroundColor: '#0c0c0e', ease: 'none', duration: 1 }, 3)
          .to('[data-sx-bg]', { backgroundColor: '#121316', ease: 'none', duration: 1 }, 4)
        const counters = gsap.utils.toArray('[data-sx-dot]', root.current)
        counters.forEach((dot, i) => {
          tl.to(dot, { opacity: 1, scale: 1.5, duration: 0.15 }, i + 0.1).to(dot, { opacity: 0.35, scale: 1, duration: 0.15 }, i + 0.85)
        })
      })
    }, root)
    return () => {
      mm.revert()
      ctx.revert()
    }
  }, [reduce])

  /* reduced-motion: a calm, un-pinned presentation */
  if (reduce) {
    return (
      <section id="story" data-nav="overview" className="bg-obsidian px-5 py-24 sm:px-8 lg:px-12" aria-label="The watch, in five moments">
        <WatchStage ctrl={ctrl} className="mx-auto h-[70svh] max-w-3xl" />
        <ol className="mx-auto mt-16 grid max-w-5xl gap-10 md:grid-cols-2">
          {SCENES.map((s) => (
            <li key={s.n} className="border-t border-white/15 pt-6">
              <p className="eyebrow mb-3">
                {s.n} — {s.kicker}
              </p>
              <h2 className="text-3xl font-extralight text-ivory">{s.title}</h2>
              <p className="mt-3 text-ivory/65">{s.body}</p>
            </li>
          ))}
        </ol>
      </section>
    )
  }

  return (
    <section id="story" data-nav="overview" ref={root} className="relative h-[100svh] w-full overflow-hidden" aria-label="The watch, in five moments">
      <div data-sx-bg className="absolute inset-0 bg-[#060607]" />
      <div
        data-sx-glow
        className="absolute inset-0 opacity-0"
        style={{ background: 'radial-gradient(ellipse 55% 55% at 50% 48%, rgba(201,169,106,0.10), rgba(255,255,255,0.03) 45%, transparent 72%)' }}
        aria-hidden="true"
      />
      <WatchStage ctrl={ctrl} eager={false} drag={false} className="absolute inset-0 pointer-events-none" lighting="studio" label="AURELIS ONE rotating through five scenes" />
      <div className="vignette absolute inset-0" aria-hidden="true" />

      {SCENES.map((s) => (
        <div
          key={s.n}
          className={`pointer-events-none absolute inset-x-5 bottom-[calc(var(--tabbar)+2.5svh)] sm:inset-x-8 lg:bottom-[7svh] lg:inset-x-auto ${sideClass[s.side]}`}
        >
          <div data-scene className={`flex flex-col ${s.side === 'center' ? 'lg:items-center' : ''}`}>
            <p className="eyebrow mb-4">
              {s.n} <span className="mx-2 text-ivory/30">/</span> {s.kicker}
            </p>
            <h2 className="display text-[clamp(2.1rem,5vw,4.6rem)] font-extralight leading-[0.98] text-ivory">{s.title}</h2>
            <p className="mt-5 max-w-sm text-[0.95rem] leading-relaxed text-ivory/60">{s.body}</p>
          </div>
        </div>
      ))}

      {/* progress rail */}
      <div className="absolute right-5 top-1/2 hidden -translate-y-1/2 flex-col items-center gap-4 lg:flex sm:right-8" aria-hidden="true">
        {SCENES.map((s) => (
          <span key={s.n} data-sx-dot className="block h-1.5 w-1.5 rounded-full bg-champagne opacity-35" />
        ))}
      </div>
      <div className="absolute left-0 top-0 h-full w-px bg-white/[0.06]" aria-hidden="true">
        <div data-sx-progress className="h-full origin-top bg-champagne/70" />
      </div>
    </section>
  )
}
