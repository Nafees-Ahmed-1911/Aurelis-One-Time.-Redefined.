import { createContext, useContext } from 'react'

export const AppContext = createContext({
  config: { case: 'titanium', strap: 'black', face: 'minimal' },
  setConfig: () => {},
  openReserve: () => {},
  introDone: true,
})

export const useApp = () => useContext(AppContext)

export function scrollToId(id) {
  const el = document.getElementById(id)
  if (!el) return
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches
  const top = el.getBoundingClientRect().top + window.scrollY
  window.scrollTo({ top, behavior: reduce ? 'auto' : 'smooth' })
}
