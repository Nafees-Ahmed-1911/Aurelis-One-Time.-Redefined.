import { useEffect, useRef } from 'react'
import { CASES, STRAPS } from '../lib/watchConfig'
import { SCREEN_W, SCREEN_H, drawTransition } from '../lib/watchScreens'

/**
 * CSS + 2D-canvas presentation used when WebGL is unavailable.
 * It is a static, layered rendering — not a 3D model — and follows the same controller.
 */
export default function WatchFallback({ ctrl }) {
  const canvasRef = useRef(null)
  const caseRef = useRef(null)
  const strapA = useRef(null)
  const strapB = useRef(null)

  useEffect(() => {
    const cv = canvasRef.current
    const ctx = cv.getContext('2d')
    let raf
    let last = 0
    const loop = (now) => {
      raf = requestAnimationFrame(loop)
      if (now - last < 200) return
      last = now
      const c = ctrl.current
      drawTransition(ctx, c.screen, c.prevScreen, c.mix, Date.now())
      cv.style.opacity = Math.min(1, c.display)
      const cs = CASES.find((x) => x.key === c.caseKey) || CASES[0]
      const st = STRAPS.find((x) => x.key === c.strapKey) || STRAPS[0]
      caseRef.current.style.background = `linear-gradient(145deg, ${cs.color}, #101012 140%)`
      const sg = `linear-gradient(180deg, ${st.color}, #060607)`
      strapA.current.style.background = sg
      strapB.current.style.background = sg.replace('180deg', '0deg')
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [ctrl])

  return (
    <div className="absolute inset-0 grid place-items-center overflow-hidden">
      <div className="relative" style={{ width: 'min(46vw, 260px)', aspectRatio: '38 / 46' }}>
        <div ref={strapA} className="absolute left-[8%] right-[8%] -top-[70%] h-[80%] rounded-t-3xl" />
        <div ref={strapB} className="absolute left-[8%] right-[8%] -bottom-[70%] h-[80%] rounded-b-3xl" />
        <div
          ref={caseRef}
          className="absolute inset-0 rounded-[28%] p-[8%] shadow-[0_30px_80px_rgba(0,0,0,.7),inset_0_1px_0_rgba(255,255,255,.4)]"
        >
          <div className="h-full w-full rounded-[22%] bg-black p-[2%] shadow-[inset_0_0_0_2px_rgba(255,255,255,.12)]">
            <canvas ref={canvasRef} width={SCREEN_W} height={SCREEN_H} className="h-full w-full rounded-[20%]" />
          </div>
        </div>
      </div>
      <p className="absolute bottom-3 left-0 right-0 text-center text-[10px] tracking-[0.2em] uppercase text-white/35">
        3D unavailable · static presentation
      </p>
    </div>
  )
}
