export default function Logo({ className = '', size = 'md' }) {
  const s = size === 'lg' ? 'text-2xl' : 'text-[0.95rem]'
  return (
    <span className={`inline-flex items-center gap-3 ${className}`}>
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" aria-hidden="true">
        <path d="M12 2.5 20.5 21.5h-3.6L12 10.6 7.1 21.5H3.5L12 2.5Z" fill="currentColor" opacity=".95" />
        <path d="M8.6 16.2h6.8" stroke="#c9a96a" strokeWidth="1.4" strokeLinecap="round" />
      </svg>
      <span className={`${s} font-light tracking-[0.42em] pl-[0.1em]`}>AURELIS</span>
    </span>
  )
}
