import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Activity, BatteryCharging, Bell, HeartPulse, LayoutGrid, Moon, Watch } from 'lucide-react'
import WatchStage from './WatchStage'
import { FEATURES, makeCtrl, setScreen } from '../lib/watchConfig'
import { gsap } from '../lib/gsap'
import { useScrollAnimations } from '../hooks/useScrollAnimations'

const ICONS = { health: Activity, heart: HeartPulse, sleep: Moon, fitness: Watch, notify: Bell, faces: LayoutGrid, battery: BatteryCharging }

export default function FeaturesSection() {
  const root = useRef(null)
  const [sel, setSel] = useState(0)
  const ctrl = useRef(
    makeCtrl({ rotY: -0.18, rotX: 0.04, camZ: typeof window !== 'undefined' && window.innerWidth < 640 ? 19 : 15, light: 1.1, display: 1, float: 1, pointer: 1, glow: 0.25, screen: { type: 'feature', key: 'health' } }),
  )
  useScrollAnimations(root)

  useEffect(() => {
    const f = FEATURES[sel]
    setScreen(ctrl, { type: 'feature', key: f.key })
    gsap.to(ctrl.current, { rotY: f.rotY, duration: 1.2, ease: 'power3.out', overwrite: 'auto' })
    gsap.fromTo(ctrl.current, { sweep: -4, sweepI: 1 }, { sweep: 4, duration: 1, ease: 'power2.inOut' })
    gsap.to(ctrl.current, { sweepI: 0, duration: 0.3, delay: 0.9 })
  }, [sel])

  const onKey = (e) => {
    if (!['ArrowDown', 'ArrowUp', 'ArrowRight', 'ArrowLeft'].includes(e.key)) return
    e.preventDefault()
    const dir = e.key === 'ArrowDown' || e.key === 'ArrowRight' ? 1 : -1
    const next = (sel + dir + FEATURES.length) % FEATURES.length
    setSel(next)
    root.current?.querySelectorAll('[role="tab"]')[next]?.focus()
  }

  const f = FEATURES[sel]

  return (
    <section id="features" data-nav="features" ref={root} className="relative bg-obsidian py-20 sm:py-28 lg:py-40">
      <div className="mx-auto max-w-[1600px] px-5 sm:px-8 lg:px-12">
        <div className="mb-14 grid gap-8 lg:mb-20 lg:grid-cols-12 lg:items-end">
          <div className="lg:col-span-8">
            <p data-reveal className="eyebrow mb-6">
              Smart features
            </p>
            <h2 data-lines className="display text-[clamp(2.4rem,6vw,5.6rem)] font-extralight text-ivory" aria-label="Intelligence, made quiet.">
              <span className="mask block" aria-hidden="true">
                <span data-line className="block">Intelligence,</span>
              </span>
              <span className="mask block" aria-hidden="true">
                <span data-line className="block serif-it text-champagne">made quiet.</span>
              </span>
            </h2>
          </div>
          <p data-reveal className="max-w-sm text-[0.95rem] leading-relaxed text-ivory/55 lg:col-span-4 lg:justify-self-end">
            Choose a feature and the watch responds. Drag the watch to turn it.
          </p>
        </div>

        <div className="flex flex-col gap-8 lg:grid lg:grid-cols-12 lg:gap-16">
          {/* watch */}
          <div className="sticky top-3 z-20 order-1 lg:static lg:order-2 lg:col-span-7">
            <div className="relative overflow-hidden rounded-[1.5rem] border border-white/[0.07] sm:rounded-[2rem] bg-[radial-gradient(ellipse_at_50%_35%,#1d1e22,#0a0a0b_72%)]">
              <WatchStage ctrl={ctrl} drag className="h-[38svh] min-h-[280px] w-full cursor-grab active:cursor-grabbing sm:h-[62svh] sm:min-h-[420px] lg:h-[78svh]" label={`AURELIS ONE showing the ${f.title} screen`} />
              <div className="pointer-events-none absolute left-5 top-5 flex items-center gap-3 text-[0.6rem] font-medium uppercase tracking-[0.28em] text-ivory/50 sm:left-7 sm:top-7">
                <span className="relative flex h-2 w-2">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-champagne/70 motion-reduce:hidden" />
                  <span className="relative inline-flex h-2 w-2 rounded-full bg-champagne" />
                </span>
                Live preview
              </div>
              {f.concept && (
                <div className="pointer-events-none absolute left-5 top-12 rounded-full border border-champagne/40 px-3 py-1 text-[0.58rem] font-medium uppercase tracking-[0.26em] text-champagne sm:left-auto sm:right-7 sm:top-7">
                  Concept · sample data
                </div>
              )}
            </div>
          </div>

          {/* list */}
          <div className="order-2 lg:order-1 lg:col-span-5">
            <div role="tablist" aria-orientation="vertical" aria-label="AURELIS ONE features" onKeyDown={onKey} className="border-t border-white/10">
              {FEATURES.map((ft, i) => {
                const Icon = ICONS[ft.key]
                const on = i === sel
                return (
                  <div key={ft.key} className="border-b border-white/10">
                    <button
                      role="tab"
                      id={`ft-${ft.key}`}
                      aria-selected={on}
                      aria-controls="ft-panel"
                      tabIndex={on ? 0 : -1}
                      type="button"
                      onClick={() => setSel(i)}
                      className="group flex w-full items-center gap-5 py-5 text-left"
                    >
                      <span
                        className={`grid h-10 w-10 shrink-0 place-items-center rounded-full border transition-all duration-500 ${
                          on ? 'border-champagne bg-champagne/10 text-champagne shadow-[0_0_24px_rgba(201,169,106,.35)]' : 'border-white/15 text-ivory/55 group-hover:border-white/40'
                        }`}
                      >
                        <Icon size={17} strokeWidth={1.4} />
                      </span>
                      <span className="flex-1">
                        <span className={`block text-[1.15rem] font-light tracking-tight transition-colors duration-500 ${on ? 'text-ivory' : 'text-ivory/60 group-hover:text-ivory/85'}`}>{ft.title}</span>
                        <span className="block text-[0.7rem] uppercase tracking-[0.2em] text-ivory/35">{ft.short}</span>
                      </span>
                      <span className={`font-mono text-[0.62rem] tracking-widest transition-colors ${on ? 'text-champagne' : 'text-ivory/25'}`}>0{i + 1}</span>
                    </button>
                    <AnimatePresence initial={false}>
                      {on && (
                        <motion.div
                          key="p"
                          id="ft-panel"
                          role="tabpanel"
                          aria-labelledby={`ft-${ft.key}`}
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.55, ease: [0.2, 0.7, 0.2, 1] }}
                          className="overflow-hidden"
                        >
                          <p className="max-w-md pb-6 pl-[3.75rem] text-[0.92rem] leading-relaxed text-ivory/60">{ft.body}</p>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                )
              })}
            </div>
            <p className="mt-6 text-[0.68rem] leading-relaxed text-ivory/40">
              Health, battery and sensor features are concept illustrations using sample data. They are not verified specifications or medical claims.
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
