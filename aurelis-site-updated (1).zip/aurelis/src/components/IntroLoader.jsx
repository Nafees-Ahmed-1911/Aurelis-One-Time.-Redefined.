import { useEffect, useLayoutEffect, useRef } from 'react'
import { gsap } from '../lib/gsap'

/** Brief, skippable brand intro. Calls onDone as the curtain starts lifting so the hero can begin underneath. */
export default function IntroLoader({ onDone }) {
  const root = useRef(null)
  const tlRef = useRef(null)
  const doneRef = useRef(false)

  const finish = () => {
    if (doneRef.current) return
    doneRef.current = true
    tlRef.current?.kill()
    onDone()
    gsap.to(root.current, {
      clipPath: 'inset(0% 0% 100% 0%)',
      duration: 0.9,
      ease: 'power4.inOut',
      onComplete: () => root.current && (root.current.style.display = 'none'),
    })
  }

  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const letters = root.current.querySelectorAll('[data-l]')
      gsap.set(letters, { yPercent: 110 })
      const tl = gsap.timeline({ onComplete: finish })
      tlRef.current = tl
      tl.to(letters, { yPercent: 0, duration: 0.9, ease: 'power4.out', stagger: 0.06 }, 0.1)
        .fromTo('[data-bar]', { scaleX: 0 }, { scaleX: 1, duration: 1.4, ease: 'power2.inOut' }, 0.2)
        .fromTo('[data-tag]', { autoAlpha: 0 }, { autoAlpha: 1, duration: 0.8 }, 0.6)
        .to({}, { duration: 0.15 })
    }, root)
    return () => ctx.revert()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    const prev = document.documentElement.style.overflow
    document.documentElement.style.overflow = 'hidden'
    const key = (e) => (e.key === 'Escape' || e.key === 'Enter') && finish()
    window.addEventListener('keydown', key)
    return () => {
      document.documentElement.style.overflow = prev
      window.removeEventListener('keydown', key)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <div
      ref={root}
      className="fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#060607]"
      style={{ clipPath: 'inset(0% 0% 0% 0%)' }}
      role="status"
      aria-label="Loading AURELIS ONE"
    >
      <div className="flex overflow-hidden pb-2 text-[clamp(1.8rem,6vw,3.4rem)] font-extralight text-ivory" aria-hidden="true">
        {'AURELIS'.split('').map((ch, i) => (
          <span key={i} data-l className="inline-block px-[0.17em]">
            {ch}
          </span>
        ))}
      </div>
      <p data-tag className="mt-4 text-[0.62rem] uppercase tracking-[0.5em] text-champagne">
        One
      </p>
      <div className="mt-10 h-px w-[min(240px,50vw)] bg-white/10">
        <div data-bar className="h-full origin-left bg-champagne" />
      </div>
      <button
        type="button"
        onClick={finish}
        className="absolute bottom-8 right-6 text-[0.66rem] uppercase tracking-[0.3em] text-ivory/55 transition-colors hover:text-ivory sm:right-10"
      >
        Skip intro
      </button>
    </div>
  )
}
