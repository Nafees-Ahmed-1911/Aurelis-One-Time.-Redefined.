import { useEffect, useRef } from 'react'
import { SCREEN_W, SCREEN_H, drawScreen } from '../lib/watchScreens'

const FIXED = new Date(2026, 9, 26, 10, 9, 36).getTime()

/** Static 2D thumbnail of a watch face. */
export default function FacePreview({ face, className = '' }) {
  const ref = useRef(null)
  useEffect(() => {
    const draw = () => drawScreen(ref.current.getContext('2d'), { type: 'face', key: face }, FIXED)
    draw()
    // redraw once webfonts have loaded so numerals use Manrope
    document.fonts?.ready.then(draw)
  }, [face])
  return <canvas ref={ref} width={SCREEN_W} height={SCREEN_H} className={className} aria-hidden="true" />
}
