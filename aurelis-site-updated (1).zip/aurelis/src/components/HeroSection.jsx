import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import { ArrowRight } from 'lucide-react'
import WatchStage from './WatchStage'
import SplitChars from './SplitChars'
import { gsap, ScrollTrigger } from '../lib/gsap'
import { makeCtrl } from '../lib/watchConfig'
import { useApp, scrollToId } from '../context'
import { prefersReducedMotion } from '../hooks/useEnv'

export default function HeroSection() {
  const { introDone } = useApp()
  const root = useRef(null)
  const ctx = useRef(null)
  const tl = useRef(null)
  const desktop = useMemo(() => typeof window !== 'undefined' && window.matchMedia('(min-width: 1024px)').matches, [])
  const ctrl = useRef(
    makeCtrl({
      rotY: 0.6,
      rotX: 0.04,
      light: 0,
      display: 0,
      camZ: 17,
      shiftX: desktop ? 0.12 : 0,
      shiftY: desktop ? 0.02 : 0.15,
      float: 0,
      pointer: 0,
      caseKey: 'titanium',
      strapKey: 'black',
      screen: { type: 'face', key: 'minimal' },
    }),
  )

  useLayoutEffect(() => {
    const c = ctrl.current
    if (prefersReducedMotion()) {
      Object.assign(c, { rotY: -0.55, rotX: 0.12, light: 1, display: 1, glow: 0.4, camZ: 16.5, float: 0, pointer: 1 })
      return
    }
    ctx.current = gsap.context(() => {
      const chars = root.current.querySelectorAll('[data-char]')
      gsap.set(chars, { yPercent: 115 })
      gsap.set('[data-hero-fade]', { autoAlpha: 0, y: 26 })
      gsap.set('[data-beam]', { autoAlpha: 0, left: '-4%' })
      gsap.set('[data-cue]', { autoAlpha: 0 })

      const t = gsap.timeline({ paused: true, defaults: { ease: 'power3.out' } })
      tl.current = t
      // 2 — a thin beam of light crosses the metal edge
      t.to(c, { sweepI: 1, duration: 0.25 }, 0)
        .fromTo(c, { sweep: -4.5 }, { sweep: 4.5, duration: 1.7, ease: 'power2.inOut' }, 0.05)
        .to('[data-beam]', { autoAlpha: 1, duration: 0.2 }, 0.05)
        .to('[data-beam]', { left: '106%', duration: 1.7, ease: 'power2.inOut' }, 0.05)
        .to('[data-beam]', { autoAlpha: 0, duration: 0.3 }, 1.5)
        // 3 — silhouette emerges
        .to(c, { light: 0.4, duration: 1.4 }, 0.45)
        // 4 — rotate into three-quarter view while the camera eases in
        .to(c, { rotY: -0.55, rotX: 0.13, duration: 2.6, ease: 'power3.inOut' }, 0.5)
        .to(c, { camZ: 16.5, duration: 3, ease: 'power2.out' }, 0.4)
        .to(c, { light: 1, duration: 1.6, ease: 'power2.inOut' }, 1.5)
        .to(c, { sweepI: 0.25, duration: 1.2 }, 1.9)
        // 5 — display wakes with a luminous pulse
        .to(c, { display: 1.4, glow: 1, duration: 0.45, ease: 'power2.out' }, 2.35)
        .to(c, { display: 1, glow: 0.35, duration: 1, ease: 'sine.inOut' }, 2.8)
        // 6 — headline
        .to(chars, { yPercent: 0, duration: 1.2, ease: 'power4.out', stagger: 0.04 }, 2.0)
        // 7 — copy + CTAs
        .to('[data-hero-fade]', { autoAlpha: 1, y: 0, duration: 1, stagger: 0.12 }, 2.7)
        // 8 — floating + pointer parallax
        .to(c, { float: 1, pointer: 1, duration: 1.6, ease: 'sine.inOut' }, 3)
        // 9 — scroll cue
        .to('[data-cue]', { autoAlpha: 1, duration: 1 }, 3.5)
    }, root)
    return () => {
      ctx.current?.revert()
      tl.current = null
    }
  }, [])

  useEffect(() => {
    if (!introDone || !tl.current) return
    tl.current.timeScale(1.12).play()
    // after the intro, let scrolling gently push the scene back
    const end = () =>
      ctx.current?.add(() => {
        gsap.to(ctrl.current, {
          camZ: 20,
          light: 0.55,
          scrollTrigger: { trigger: root.current, start: 'top top', end: 'bottom top', scrub: 1 },
        })
        gsap.to('[data-hero-content]', {
          yPercent: -14,
          autoAlpha: 0.1,
          ease: 'none',
          scrollTrigger: { trigger: root.current, start: 'top top', end: '70% top', scrub: true },
        })
        ScrollTrigger.refresh()
      })
    tl.current.eventCallback('onComplete', end)
    return () => tl.current?.eventCallback('onComplete', null)
  }, [introDone])

  return (
    <section
      id="overview"
      data-nav="overview"
      ref={root}
      className="relative min-h-[640px] h-[100svh] w-full overflow-hidden bg-obsidian"
      aria-labelledby="hero-title"
    >
      {/* atmosphere */}
      <div className="pointer-events-none absolute inset-0" aria-hidden="true">
        <div className="haze-a absolute -left-[10%] top-[10%] h-[70%] w-[60%] rounded-full bg-[radial-gradient(closest-side,rgba(201,169,106,0.10),transparent)]" />
        <div className="haze-b absolute -right-[10%] top-[30%] h-[70%] w-[60%] rounded-full bg-[radial-gradient(closest-side,rgba(120,135,160,0.10),transparent)]" />
      </div>

      {/* oversized headline sits behind the product */}
      <div
        data-hero-content
        className="absolute inset-x-0 bottom-[calc(var(--tabbar)+15.5rem)] z-[1] px-5 min-[420px]:bottom-[43svh] sm:px-8 lg:bottom-auto lg:top-[27svh] lg:px-12"
      >
        <h1
          id="hero-title"
          className="display text-[clamp(3.4rem,15vw,12.5rem)] lg:text-[clamp(3.2rem,12.6vw,12.5rem)] font-extralight leading-[0.9] text-ivory"
        >
          <span className="block overflow-hidden">
            <SplitChars text="TIME." />
          </span>
          <span className="block overflow-hidden">
            <SplitChars text="REDEFINED." />
          </span>
        </h1>
      </div>

      <WatchStage ctrl={ctrl} eager lighting="studio" className="absolute inset-0 z-[2] pointer-events-none" label="AURELIS ONE smartwatch" />

      {/* travelling beam */}
      <div
        data-beam
        className="pointer-events-none absolute top-0 z-[3] h-full w-px bg-gradient-to-b from-transparent via-white to-transparent shadow-[0_0_40px_12px_rgba(255,244,220,0.35)] mix-blend-screen"
        aria-hidden="true"
      />
      <div className="vignette absolute inset-0 z-[3]" aria-hidden="true" />

      <div
        data-hero-content
        className="absolute inset-x-0 bottom-0 z-[4] flex flex-col gap-7 px-5 pb-[calc(var(--tabbar)+1.25rem)] sm:px-8 lg:flex-row lg:items-end lg:justify-between lg:px-12 lg:pb-[9svh]"
      >
        <div className="max-w-md">
          <p data-hero-fade className="eyebrow mb-4">
            Introducing AURELIS ONE
          </p>
          <p data-hero-fade className="text-[0.92rem] leading-relaxed text-ivory/70 sm:text-lg">
            Precision engineered. Beautifully intelligent. Designed for every moment.
          </p>
        </div>
        <div data-hero-fade className="grid grid-cols-[1.35fr_1fr] gap-3 sm:flex sm:flex-wrap sm:items-center">
          <button type="button" className="btn btn-primary" onClick={() => scrollToId('story')}>
            <span className="sm:hidden">Discover</span><span className="hidden sm:inline">Discover AURELIS ONE</span> <ArrowRight size={14} />
          </button>
          <button type="button" className="btn btn-ghost" onClick={() => scrollToId('technology')}>
            <span className="sm:hidden">Technology</span>
          <span className="hidden sm:inline">Explore the technology</span>
          </button>
        </div>
      </div>

      <div data-cue className="pointer-events-none absolute bottom-3 left-1/2 z-[4] hidden -translate-x-1/2 flex-col items-center gap-2 lg:flex" aria-hidden="true">
        <span className="text-[0.58rem] uppercase tracking-[0.4em] text-ivory/45">Scroll</span>
        <span className="scroll-cue block h-8 w-px bg-ivory/60" />
      </div>
    </section>
  )
}
