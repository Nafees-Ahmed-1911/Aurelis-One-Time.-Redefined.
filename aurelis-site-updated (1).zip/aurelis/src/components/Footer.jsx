import { Mail, MapPin, Phone } from 'lucide-react'
import Logo from './Logo'
import Credit from './Credit'
import { scrollToId, useApp } from '../context'

const NAV = [
  ['overview', 'Overview'],
  ['design', 'Design'],
  ['features', 'Features'],
  ['technology', 'Technology'],
  ['customize', 'Customise'],
  ['specs', 'Specifications'],
]

const P = { width: 18, height: 18, viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeWidth: 1.4, strokeLinecap: 'round', strokeLinejoin: 'round' }
const SOCIAL = [
  {
    name: 'Instagram',
    href: 'https://www.instagram.com/',
    icon: (
      <svg {...P} aria-hidden="true">
        <rect x="3" y="3" width="18" height="18" rx="5" />
        <circle cx="12" cy="12" r="4" />
        <circle cx="17.2" cy="6.8" r=".6" fill="currentColor" />
      </svg>
    ),
  },
  {
    name: 'X',
    href: 'https://x.com/',
    icon: (
      <svg {...P} aria-hidden="true">
        <path d="M4 4l16 16M20 4L4 20" />
      </svg>
    ),
  },
  {
    name: 'YouTube',
    href: 'https://www.youtube.com/',
    icon: (
      <svg {...P} aria-hidden="true">
        <rect x="2.5" y="5.5" width="19" height="13" rx="4" />
        <path d="M10 9.5l5 2.5-5 2.5z" fill="currentColor" />
      </svg>
    ),
  },
  {
    name: 'LinkedIn',
    href: 'https://www.linkedin.com/',
    icon: (
      <svg {...P} aria-hidden="true">
        <rect x="3" y="3" width="18" height="18" rx="3" />
        <path d="M8 11v5M8 8v.01M12 16v-5m0 2c0-1.5 1-2 2-2s2 .7 2 2v3" />
      </svg>
    ),
  },
]

export default function Footer() {
  const { openReserve } = useApp()
  return (
    <footer className="border-t border-white/10 bg-[#040405] text-ivory">
      <div className="mx-auto grid max-w-[1600px] gap-14 px-5 py-16 sm:px-8 sm:py-20 lg:grid-cols-12 lg:px-12">
        <div className="lg:col-span-5">
          <Logo size="lg" />
          <p className="mt-6 max-w-sm text-[0.92rem] leading-relaxed text-ivory/50">
            AURELIS ONE is a concept product launch experience. Specifications, pricing and availability are placeholders.
          </p>
          <button type="button" onClick={() => openReserve(1)} className="btn btn-ghost btn-sm mt-8">
            Reserve your watch
          </button>
        </div>

        <nav aria-label="Footer" className="lg:col-span-3">
          <p className="mb-5 text-[0.62rem] font-medium uppercase tracking-[0.3em] text-champagne">Explore</p>
          <ul className="space-y-3">
            {NAV.map(([id, label]) => (
              <li key={id}>
                <a
                  href={`#${id}`}
                  onClick={(e) => {
                    e.preventDefault()
                    scrollToId(id)
                  }}
                  className="link-u text-[0.92rem] text-ivory/65 hover:text-ivory"
                >
                  {label}
                </a>
              </li>
            ))}
          </ul>
        </nav>

        <div className="lg:col-span-4">
          <p className="mb-5 text-[0.62rem] font-medium uppercase tracking-[0.3em] text-champagne">Contact</p>
          <ul className="space-y-3 text-[0.92rem] text-ivory/65">
            <li>
              <a href="mailto:mail@aurelis.com" className="flex items-center gap-3 transition-colors hover:text-ivory">
                <Mail size={15} strokeWidth={1.4} /> mail@aurelis.com
              </a>
            </li>
            <li>
              <a href="tel:+918779165205" className="flex items-center gap-3 transition-colors hover:text-ivory">
                <Phone size={15} strokeWidth={1.4} /> +91 87791 65205
              </a>
            </li>
            <li className="flex items-start gap-3">
              <MapPin size={15} strokeWidth={1.4} className="mt-1 shrink-0" /> Dhanbad, Jharkhand – 826001
            </li>
          </ul>
          <ul className="mt-8 flex gap-3">
            {SOCIAL.map((s) => (
              <li key={s.name}>
                <a
                  href={s.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={`AURELIS on ${s.name} (opens ${s.name})`}
                  className="grid h-11 w-11 place-items-center rounded-full border border-white/15 text-ivory/70 transition-colors hover:border-champagne hover:text-champagne"
                >
                  {s.icon}
                </a>
              </li>
            ))}
          </ul>
        </div>
      </div>
      <div className="flex flex-col items-center gap-3 border-t border-white/[0.06] px-5 pt-6 pb-[calc(var(--tabbar)+1.5rem)] text-center text-[0.65rem] uppercase tracking-[0.25em] text-ivory/30 lg:pb-6">
        <span>© 2026 AURELIS · Concept experience · All product details are placeholders</span>
        <Credit className="text-[0.7rem] tracking-[0.2em] text-ivory/55" />
      </div>
    </footer>
  )
}
