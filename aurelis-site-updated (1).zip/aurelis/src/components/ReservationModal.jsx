import { useEffect, useRef, useState } from 'react'
import { AnimatePresence, motion, useDragControls } from 'framer-motion'
import { Check, X } from 'lucide-react'
import { CASES, STRAPS, FACES } from '../lib/watchConfig'
import { useApp } from '../context'
import { useMedia } from '../hooks/useEnv'

const field =
  'w-full rounded-xl border border-white/15 bg-white/[0.03] px-4 py-3.5 text-base text-ivory placeholder:text-ivory/30 focus:border-champagne focus:outline-none'

function Select({ id, label, value, onChange, options }) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-[0.64rem] font-medium uppercase tracking-[0.26em] text-ivory/50">
        {label}
      </label>
      <select id={id} value={value} onChange={onChange} className={`${field} appearance-none`}>
        {options.map((o) => (
          <option key={o.key} value={o.key} className="bg-graphite">
            {o.label}
          </option>
        ))}
      </select>
    </div>
  )
}

export default function ReservationModal({ open, step, setStep, onClose }) {
  const { config, setConfig } = useApp()
  const sheet = useMedia('(max-width: 639px)')
  const controls = useDragControls()
  const dialog = useRef(null)
  const opener = useRef(null)
  const [form, setForm] = useState({ name: '', email: '', region: '', notify: true })
  const [errors, setErrors] = useState({})
  const [receipt, setReceipt] = useState(null)

  // focus management + trap + scroll lock
  useEffect(() => {
    if (!open) return
    opener.current = document.activeElement
    const prevOverflow = document.documentElement.style.overflow
    document.documentElement.style.overflow = 'hidden'
    const onKey = (e) => {
      if (e.key === 'Escape') onClose()
      if (e.key !== 'Tab' || !dialog.current) return
      const f = dialog.current.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')
      const list = [...f].filter((el) => !el.disabled && el.offsetParent !== null)
      if (!list.length) return
      const first = list[0]
      const last = list[list.length - 1]
      if (e.shiftKey && document.activeElement === first) (e.preventDefault(), last.focus())
      else if (!e.shiftKey && document.activeElement === last) (e.preventDefault(), first.focus())
    }
    window.addEventListener('keydown', onKey)
    return () => {
      window.removeEventListener('keydown', onKey)
      document.documentElement.style.overflow = prevOverflow
      opener.current?.focus?.()
    }
  }, [open, onClose])

  useEffect(() => {
    if (!open) return
    const t = setTimeout(() => dialog.current?.querySelector('[data-autofocus]')?.focus(), 80)
    return () => clearTimeout(t)
  }, [open, step])

  useEffect(() => {
    if (!open) {
      const t = setTimeout(() => {
        setReceipt(null)
        setErrors({})
      }, 400)
      return () => clearTimeout(t)
    }
  }, [open])

  const validate = () => {
    const e = {}
    if (form.name.trim().length < 2) e.name = 'Please enter your full name.'
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email)) e.email = 'Please enter a valid email address.'
    if (!form.region.trim()) e.region = 'Please tell us your country or region.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const submit = (ev) => {
    ev.preventDefault()
    if (!validate()) {
      dialog.current?.querySelector('[aria-invalid="true"]')?.focus()
      return
    }
    const id = `AUR-${Math.random().toString(36).slice(2, 8).toUpperCase()}`
    const rec = { id, ...config, name: form.name.trim(), email: form.email.trim(), region: form.region.trim(), at: new Date().toISOString() }
    try {
      const prev = JSON.parse(localStorage.getItem('aurelis-demo-reservations') || '[]')
      localStorage.setItem('aurelis-demo-reservations', JSON.stringify([...prev, rec].slice(-10)))
    } catch {
      /* storage unavailable — the confirmation still works */
    }
    setReceipt(rec)
    setStep(3)
  }

  const label = (list, k) => list.find((x) => x.key === k)?.label
  const set = (k) => (e) => setConfig((c) => ({ ...c, [k]: e.target.value }))
  const steps = ['Configure', 'Details', 'Confirmed']

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          key="reserve"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.4 }}
          className="fixed inset-0 z-[90] flex items-end justify-center bg-black/75 backdrop-blur-sm sm:items-center sm:overflow-y-auto sm:p-4"
          onMouseDown={(e) => e.target === e.currentTarget && onClose()}
        >
          <motion.div
            ref={dialog}
            role="dialog"
            aria-modal="true"
            aria-labelledby="reserve-title"
            initial={sheet ? { y: '100%' } : { opacity: 0, y: 40, scale: 0.98 }}
            animate={sheet ? { y: 0 } : { opacity: 1, y: 0, scale: 1 }}
            exit={sheet ? { y: '100%' } : { opacity: 0, y: 24 }}
            transition={{ duration: sheet ? 0.5 : 0.6, ease: [0.2, 0.7, 0.2, 1] }}
            drag={sheet ? 'y' : false}
            dragConstraints={{ top: 0, bottom: 0 }}
            dragElastic={{ top: 0, bottom: 0.6 }}
            dragListener={false}
            dragControls={controls}
            onDragEnd={(_, info) => info.offset.y > 120 && onClose()}
            className="relative max-h-[92dvh] w-full overflow-y-auto overscroll-contain rounded-t-[1.75rem] border border-white/10 bg-[#0d0d0f] p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom,0px))] text-ivory shadow-2xl sm:my-auto sm:max-w-xl sm:rounded-[1.75rem] sm:p-10"
          >
            <div aria-hidden="true" onPointerDown={(e) => controls.start(e)} style={{ touchAction: 'none' }} className="-mx-6 -mt-6 mb-3 flex h-8 cursor-grab justify-center pt-3 sm:hidden">
              <span className="block h-1 w-10 rounded-full bg-white/25" />
            </div>
            <button type="button" onClick={onClose} aria-label="Close reservation" className="absolute right-4 top-4 grid h-11 w-11 place-items-center rounded-full border border-white/15 text-ivory/70 hover:text-ivory">
              <X size={17} />
            </button>

            <ol className="mb-8 flex flex-wrap items-center gap-x-3 gap-y-1 pr-12 text-[0.6rem] font-medium uppercase tracking-[0.2em]" aria-label="Progress">
              {steps.map((s, i) => (
                <li key={s} aria-current={step === i + 1 ? 'step' : undefined} className={`flex items-center gap-3 ${step === i + 1 ? 'text-champagne' : 'text-ivory/30'}`}>
                  {i + 1}. {s}
                  {i < 2 && <span className="h-px w-5 bg-white/15" />}
                </li>
              ))}
            </ol>

            {step === 1 && (
              <div>
                <h2 id="reserve-title" className="display text-[2rem] font-extralight sm:text-4xl">
                  Your AURELIS ONE
                </h2>
                <p className="mt-3 text-[0.9rem] text-ivory/55">Choose your configuration. You can change it any time before confirming.</p>
                <div className="mt-8 grid gap-5 sm:grid-cols-3">
                  <Select id="r-case" label="Case" value={config.case} onChange={set('case')} options={CASES} />
                  <Select id="r-strap" label="Strap" value={config.strap} onChange={set('strap')} options={STRAPS} />
                  <Select id="r-face" label="Face" value={config.face} onChange={set('face')} options={FACES} />
                </div>
                <button type="button" data-autofocus className="btn btn-primary mt-9 w-full" onClick={() => setStep(2)}>
                  Continue
                </button>
              </div>
            )}

            {step === 2 && (
              <form onSubmit={submit} noValidate>
                <h2 id="reserve-title" className="display text-4xl font-extralight">
                  Your details
                </h2>
                <p className="mt-3 text-[0.9rem] text-ivory/55">
                  {label(CASES, config.case)} · {label(STRAPS, config.strap)} · {label(FACES, config.face)}
                </p>
                <div className="mt-8 space-y-5">
                  {[
                    ['name', 'Full name', 'text', 'name'],
                    ['email', 'Email', 'email', 'email'],
                    ['region', 'Country / region', 'text', 'country-name'],
                  ].map(([k, l, type, ac], i) => (
                    <div key={k}>
                      <label htmlFor={`r-${k}`} className="mb-2 block text-[0.64rem] font-medium uppercase tracking-[0.26em] text-ivory/50">
                        {l}
                      </label>
                      <input
                        id={`r-${k}`}
                        type={type}
                        autoComplete={ac}
                        value={form[k]}
                        data-autofocus={i === 0 ? '' : undefined}
                        aria-invalid={errors[k] ? 'true' : undefined}
                        aria-describedby={errors[k] ? `r-${k}-err` : undefined}
                        onChange={(e) => setForm((f) => ({ ...f, [k]: e.target.value }))}
                        className={`${field} ${errors[k] ? '!border-[#e2766b]' : ''}`}
                      />
                      {errors[k] && (
                        <p id={`r-${k}-err`} role="alert" className="mt-2 text-[0.8rem] text-[#e2766b]">
                          {errors[k]}
                        </p>
                      )}
                    </div>
                  ))}
                  <label className="flex cursor-pointer items-start gap-3 text-[0.85rem] text-ivory/60">
                    <input type="checkbox" checked={form.notify} onChange={(e) => setForm((f) => ({ ...f, notify: e.target.checked }))} className="mt-1 h-4 w-4 accent-[#c9a96a]" />
                    Notify me about launch updates.
                  </label>
                </div>
                <p className="mt-6 rounded-xl border border-champagne/25 bg-champagne/[0.05] p-4 text-[0.78rem] leading-relaxed text-ivory/60">
                  Demo flow: no payment is taken and nothing is sent to a server. Your reservation is saved only in this browser.
                </p>
                <div className="mt-7 flex gap-3">
                  <button type="button" className="btn btn-ghost" onClick={() => setStep(1)}>
                    Back
                  </button>
                  <button type="submit" className="btn btn-primary flex-1">
                    Confirm reservation
                  </button>
                </div>
              </form>
            )}

            {step === 3 && receipt && (
              <div className="text-center">
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-full border border-champagne text-champagne">
                  <Check size={24} strokeWidth={1.4} />
                </span>
                <h2 id="reserve-title" className="display mt-6 text-4xl font-extralight">
                  Reserved, {receipt.name.split(' ')[0]}.
                </h2>
                <p className="mt-3 text-[0.92rem] text-ivory/60">
                  AURELIS ONE · {label(CASES, receipt.case)} · {label(STRAPS, receipt.strap)} · {label(FACES, receipt.face)}
                </p>
                <p className="mt-6 inline-block rounded-full border border-white/15 px-5 py-2 font-mono text-sm tracking-[0.2em] text-champagne">{receipt.id}</p>
                <p className="mx-auto mt-6 max-w-sm text-[0.8rem] leading-relaxed text-ivory/45">This is a demonstration reservation — no order exists and no payment was taken.</p>
                <button type="button" data-autofocus className="btn btn-primary mt-8" onClick={onClose}>
                  Done
                </button>
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
